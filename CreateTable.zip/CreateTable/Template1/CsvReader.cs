﻿
using System.Text;
namespace Template {
    internal class CsvReader {
        readonly StreamReader _reader;
        public CsvReader(StreamReader reader, bool hasHeader = true) {
            _reader = reader;
            if (hasHeader) Names = ReadLine();
        }

        public string?[]? Names { get; private set; }
        public string?[]? Values { get; private set; }

        private string?[] ReadLine() {
            var retVal = new List<string?>();
            string? txt = null;
            int value;
            while ((value = _reader.Peek()) > 0) {
                var chr = (char)value;
                if (chr == '\r') {
                    _reader.Read();
                    continue;
                }
                if (chr == '\n') {
                    retVal.Add(txt);
                    _reader.Read();
                    break;
                }

                if (chr == ',') {
                    _reader.Read();
                    retVal.Add(txt);
                    txt = null;
                    continue;
                }
                txt = ReadString();
            }

            return retVal.ToArray();
        }
        private string? ReadString() {
            var retVal = new StringBuilder();
            int value = _reader.Peek();
            if (value == 0) return null;
            var chr = (char)value;
            bool hasEscape = chr == '\'';
            if (hasEscape) _reader.Read();

            while ((value = _reader.Peek()) > 0) {
                chr = (char)value;
                if (hasEscape) {
                    _reader.Read();
                    if (chr == '\'') break;
                    retVal.Append(chr);
                    continue;
                }

                if (",\r\n".IndexOf(chr) >= 0) break;
                retVal.Append(chr);
                _reader.Read();
            }
            if (retVal.Length == 0) return hasEscape ? string.Empty : null;
            return retVal.ToString();
        }

        public bool Next() {
            Values = ReadLine();
            return Values.Length > 0;
        }
    }
}
