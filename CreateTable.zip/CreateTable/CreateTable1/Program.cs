﻿using CreateTable;
using System;
using System.Net.Http.Headers;
using System.Reflection;
using System.Xml;
using Index = CreateTable.Index;

namespace CreateTable {
    // Note: actual namespace depends on the project name.
    internal class Program {
        static void Main(string[] args) {
            var cmdFolder = args[0];
            var inputFolder = args[1];
            var outputFolder = args[2];

            if (!Directory.Exists(inputFolder)) return;
            if (!Directory.Exists(cmdFolder)) Directory.CreateDirectory(cmdFolder);

            if (!Directory.Exists(outputFolder)) Directory.CreateDirectory(outputFolder);

            var endInfo = EnvInfo.Instance;

            var tables = new Dictionary<string, Table>();
            string? tName = null;
            Table? t = null;

            var cols = Path.Combine(inputFolder, "colunns.csv");
            using (var reader = File.OpenText(cols)) {
                var csvReader = new CsvReader(reader, false);

                while (csvReader.Next()) {
                    var tn = $"{csvReader.Values[0].Trim().ToUpper()}.{csvReader.Values[1].Trim().ToUpper()}";
                    if (tn != tName) {
                        tName = tn;
                        t = new Table {
                            Schema = csvReader.Values[0].Trim(),
                            Name = csvReader.Values[1].Trim(),
                            Type = csvReader.Values[2].Trim(),
                            Status = csvReader.Values[3].Trim(),
                            Tbspace = csvReader.Values[4]?.Trim(),
                            ITbspace = csvReader.Values[5]?.Trim(),
                            Codepage = csvReader.Values[6].Trim(),
                        };
                        if(t.Type == "T") tables[tn] = t;
                    }

                    t.Columns.Add(new Column {
                        Name = csvReader.Values[7].Trim(),
                        Colno = intParse(csvReader.Values[8].Trim()),
                        Typename = csvReader.Values[9].Trim(),
                        Length = intParse(csvReader.Values[10].Trim()),
                        Scale = intParse(csvReader.Values[11].Trim()),
                        Nulls = csvReader.Values[12].Trim() == "Y",
                        Codepage = intParse(csvReader.Values[13].Trim()),
                        Keyseq = csvReader.Values[14].Trim(),
                        Identity = csvReader.Values[15].Trim() == "Y",
                        Default = csvReader.Values[16]?.Trim(),
                        Start = intParse(csvReader.Values[17]),
                        Increment = intParse(csvReader.Values[18]),
                        Cycle = csvReader.Values[19]?.Trim() == "Y",
                        Cache = intParse(csvReader.Values[20]),
                        Order = csvReader.Values[21]?.Trim() == "Y",
                    });
                }
            }

            t = null;
            var indexes = Path.Combine(inputFolder, "indexes.csv");
            using (var reader = File.OpenText(indexes)) {
                var csvReader = new CsvReader(reader, false);

                while (csvReader.Next()) {
                    var tn = $"{csvReader.Values[0].Trim().ToUpper()}.{csvReader.Values[1].Trim().ToUpper()}";
                    t = tables[tn];
                    if (t == null) continue;
                    t.Indexes.Add(new Index {
                        Schema = csvReader.Values[2].Trim(),
                        Name = csvReader.Values[3].Trim(),
                        OwnerType = csvReader.Values[4].Trim(),
                        Columns = csvReader.Values[5].Trim(),
                        UniqueRule = csvReader.Values[6].Trim(),
                        MadeUnique = csvReader.Values[7].Trim(),
                        PCTFREE = intParse(csvReader.Values[8].Trim()),
                        Indextype = csvReader.Values[9].Trim(),
                        ColCount = intParse(csvReader.Values[10].Trim())
                    }); ;
                }
            }

            //UPDATE INDEX NAME

            foreach (var key in tables.Keys) {
                var table = tables[key];
                var inds = table.Indexes;
                var length = inds.Count;
                for (int i = 0; i < length; i++) {
                    var ind = inds[i];
                    ind.Name = $"X{(i + 1).ToString().PadLeft(2, '0')}{table.Name.Substring(1)}";
                }

            }

            var cmdF = Path.Combine(cmdFolder, $"createTables.bat");
            var cmdL = Path.Combine(cmdFolder, $"createTables.log");
            using (var cmdWriter = File.CreateText(cmdF)) {
                cmdWriter.WriteLine($"call \"{Path.Combine(cmdFolder, "setenv.bat")}\"");
                cmdWriter.WriteLine($"db2 connect to {endInfo.DbName} user {endInfo.DbUser} using {endInfo.DbPass} > \"{cmdL}\"");
                cmdWriter.WriteLine($"db2 SET SCHEMA {endInfo.DbSchema} >> \"{cmdL}\"");
                foreach (var key in tables.Keys) {
                    var table = tables[key];
                    var of = Path.Combine(outputFolder, $"CR{table.Name}.sql");
                    cmdWriter.WriteLine($"db2 -tvmf {of} >> \"{cmdL}\"");
                    using (var writer = File.CreateText(of)) {
                        CreateTable(writer, table);
                    }
                }
                cmdWriter.WriteLine($"db2 terminate");
            }

            //Drop Table
            var cmdE = Path.Combine(cmdFolder, $"dropTables.bat");
            cmdL = Path.Combine(cmdFolder, $"dropTables.log");
            var sqlE = Path.Combine(cmdFolder, $"dropTables.sql");
            using (var cmdWriter = File.CreateText(cmdE)) {
                cmdWriter.WriteLine($"call \"{Path.Combine(cmdFolder, "setenv.bat")}\"");
                cmdWriter.WriteLine($"db2 connect to {endInfo.DbName} user {endInfo.DbUser} using {endInfo.DbPass} > \"{cmdL}\"");
                cmdWriter.WriteLine($"db2 -tvmf \"{sqlE}\" >> \"{cmdL}\"");
                cmdWriter.WriteLine($"db2 terminate");
            }
            using (var cmdWriter = File.CreateText(sqlE)) {
                cmdWriter.WriteLine($"SET SCHEMA {endInfo.DbSchema};");
                foreach (var key in tables.Keys) {
                    var table = tables[key];
                    cmdWriter.WriteLine($"DROP TABLE {table.Name};");
                }
            }

            //Generate Export
            cmdE = Path.Combine(cmdFolder, $"exportData.bat");
            cmdL = Path.Combine(cmdFolder, $"exportData.log");
            sqlE = Path.Combine(cmdFolder, $"exportData.sql");
            using (var cmdWriter = File.CreateText(cmdE)) {
                cmdWriter.WriteLine($"call \"{Path.Combine(cmdFolder, "setenv.bat")}\"");
                cmdWriter.WriteLine($"db2 connect to {endInfo.DbName} user {endInfo.DbUser} using {endInfo.DbPass} > \"{cmdL}\"");
                cmdWriter.WriteLine($"db2 -tvmf \"{sqlE}\" >> \"{cmdL}\"");
                cmdWriter.WriteLine($"db2 terminate");
            }
            using (var cmdWriter = File.CreateText(sqlE)) {
                cmdWriter.WriteLine($"SET SCHEMA {endInfo.DbSchema};");
                foreach (var key in tables.Keys) {
                    var table = tables[key];
                    cmdWriter.WriteLine($"EXPORT TO \"{endInfo.ExportFolder}\\{table.Name}.del\" OF DEL MODIFIED BY CHARDEL~  SELECT * FROM {table.Name};");
                }
            }

            //Generate Import
            cmdE = Path.Combine(cmdFolder, $"importData.bat");
            cmdL = Path.Combine(cmdFolder, $"importData.log");
            sqlE = Path.Combine(cmdFolder, $"importData.sql");
            using (var cmdWriter = File.CreateText(cmdE)) {
                cmdWriter.WriteLine($"call \"{Path.Combine(cmdFolder, "setenv.bat")}\"");
                cmdWriter.WriteLine($"db2 connect to {endInfo.DbName} user {endInfo.DbUser} using {endInfo.DbPass} > \"{cmdL}\"");
                cmdWriter.WriteLine($"db2 -tvmf \"{sqlE}\" >> \"{cmdL}\"");
                cmdWriter.WriteLine($"db2 terminate");
            }
            using (var cmdWriter = File.CreateText(sqlE)) {
                cmdWriter.WriteLine($"SET SCHEMA {endInfo.DbSchema};");
                foreach (var key in tables.Keys) {
                    var table = tables[key];
                    cmdWriter.WriteLine($"IMPORT FROM \"{endInfo.ExportFolder}\\{table.Name}.del\" OF DEL MODIFIED BY CHARDEL~  COMMITCOUNT 4000 INSERT_UPDATE INTO {table.Name};");
                }
            }
        }

        static int intParse(string? txt, int faultValue = -1) {
            if (string.IsNullOrWhiteSpace(txt)) return faultValue;
            if (!double.TryParse(txt, out double v)) return faultValue;
            return (int)v;
        }

        static void CreateTable(StreamWriter writer, Table table) {
            writer.WriteLine($"-- THE FOLLOWING SQL IS USED TO CREATE THE TABLESPACE");
            writer.WriteLine($"-- TABLE, AND UNIQUE INDEX FOR THE TABLE: {table.Name}");
            writer.WriteLine($"-- *****************************************************************");
            writer.WriteLine($"-- CREATE TABLESPACE");
            writer.WriteLine($"-- *****************************************************************");
            writer.WriteLine($"-- *****************************************************************");
            writer.WriteLine($"-- CREATE TABLE");
            writer.WriteLine($"-- *****************************************************************");

            writer.Write("CREATE TABLE ");
            writer.WriteLine(table.Name);
            writer.Write("      (");
            var cols = table.Columns;
            var length = cols.Count;
            for (int i = 0; i < length; i++) {
                var col = cols[i];
                if (i > 0) {
                    writer.WriteLine(",");
                    writer.Write("       ");
                }
                writer.Write(col.Name.PadRight(21));
                writer.Write(" ");
                writer.Write(GetTypeName(col).PadRight(17));
                writer.Write(GetOption(col).PadRight(21));

                if (col.Identity) {
                    writer.WriteLine();
                    writer.WriteLine("                                              GENERATED ALWAYS");
                    writer.WriteLine("                                              AS IDENTITY ( START WITH");
                    writer.Write("                                              ");
                    writer.Write(col.Start);
                    writer.Write(", INCREMENT BY ");
                    writer.Write(col.Increment);
                    writer.WriteLine(", CACHE");
                    writer.Write("                                              ");
                    var a = $"{col.Cache}";
                    if (col.Cycle) a += ", CYCLE";
                    a += ")";
                    writer.Write(a.PadRight(20));
                }
            }
            writer.WriteLine(")");
            writer.WriteLine($"  IN {table.Tbspace};");

            var indexes = table.Indexes;
            length = indexes.Count;
            for (int i = 0; i < length; i++) {
                CreateIndexes(writer, table, indexes[i]);
            }
        }
        static string GetTypeName(Column col) {
            var typeName = col.Typename;
            if (typeName == "CHARACTER") typeName = "CHAR";

            if (col.Length > 0 && typeName.IndexOf("CHAR") > -1) {
                return $"{typeName}({col.Length.ToString().PadLeft(2, '0')})";
            }

            if (typeName == "DECIMAL") {
                return $"{typeName}({col.Length.ToString().PadLeft(2, '0')}, {col.Scale.ToString().PadLeft(2, '0')})";
            }
            return typeName;
        }
        static string GetOption(Column col) {
            return !col.Nulls ? col.Default != null ? "NOT NULL WITH DEFAULT" : "NOT NULL" : col.Default != null ? "WITH DEFAULT" : "";
        }


        static void CreateIndexes(StreamWriter writer, Table table, Index index) {
            writer.WriteLine($"-- *****************************************************************");
            if (index.UniqueRule == "D") writer.WriteLine($"-- CREATE INDEX");
            else writer.WriteLine($"-- CREATE UNIQUE INDEX");
            writer.WriteLine($"-- *****************************************************************");


            if (index.UniqueRule == "D") writer.Write("CREATE INDEX".PadRight(29));
            else writer.Write("CREATE UNIQUE INDEX".PadRight(29));
            writer.WriteLine(index.Name);

            writer.Write("       ON                    ");
            writer.WriteLine(table.Name);
            writer.Write("      (");

            var col = index.Columns;
            var length = index.ColCount;
            for (int i = 0; i < length; i++) {
                var name = GetName(ref col, out bool asc);
                if (i > 0) {
                    writer.WriteLine(',');
                    writer.Write("       ");
                }
                writer.Write(name);
            }
            writer.Write(")");

            if (index.PCTFREE > 0) {
                writer.WriteLine();
                writer.Write("       PCTFREE ");
                writer.Write(index.PCTFREE);
            }

            if (index.UniqueRule == "P") {
                writer.WriteLine();
                writer.Write("       CLUSTER");
            }
            writer.WriteLine(';');

            if (index.UniqueRule != "P") return;
            writer.WriteLine($"-- *****************************************************************");
            writer.WriteLine($"-- ALTER TABLE ADD PRIMARY KEY");
            writer.WriteLine($"-- *****************************************************************");
            writer.Write("ALTER TABLE ");
            writer.WriteLine(table.Name);
            writer.WriteLine("  ADD PRIMARY KEY");
            writer.Write("      (");

            col = index.Columns;
            length = index.ColCount;
            for (int i = 0; i < length; i++) {
                var name = GetName(ref col, out bool asc);
                if (i > 0) {
                    writer.WriteLine(',');
                    writer.Write("       ");
                }
                writer.Write(name);
                if (!asc) writer.Write(" DESC");
            }
            writer.WriteLine(");");

        }
        static string GetName(ref string col, out bool asc) {
            asc = col[0] == '+';
            if (!asc && col[0] != '-') throw new InvalidDataException();

            var idx = col.IndexOf('+', 1);
            if (idx < 0) idx = col.IndexOf('-', 1);
            if (idx < 0) idx = col.Length;
            var name = col.Substring(1, idx - 1);
            col = col.Substring(idx);
            return name;
        }
    }
    class EnvInfo {
        public static EnvInfo Instance = new();
        private EnvInfo() {
            DbName = GetVar("DBNAME", "UDIPPV26");
            DbSchema = GetVar("DBSCHEMA", "IPPV26");
            DbUser = GetVar("DBUSER", "IPPV26");
            DbPass = GetVar("DBPASS", "vnutd3v");
            ExportFolder = GetVar("FdData", "D:\\ING\\Data");
        }

        public string DbName { get; }
        public string DbSchema { get; }
        public string DbUser { get; }
        public string DbPass { get; }

        public string ExportFolder { get; }

        private static string GetVar(string name, string defaultValue)
            => Environment.GetEnvironmentVariable(name) ?? defaultValue;
    }
}