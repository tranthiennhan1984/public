﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ls {
    internal class Program {
        static void Main(string[] args) {
            if (args.Length == 1 && args[0].ToLower() == "-h") {
                Help();
                return;
            }

            List(args);
        }
        static void List(string[] args) { 
            SearchOption option = SearchOption.TopDirectoryOnly;
            bool ext = true;
            bool fullPath = false;
            string searchPattern = null;
            string dirPath = null;
            var length = args.Length;
            for (int i = 0; i < length; i++) {
                switch (args[i]) {
                    case "-r":
                        option = SearchOption.AllDirectories;
                        break;
                    case "-x":
                        ext = false;
                        break;
                    case "-f":
                        fullPath = true;
                        break;
                    case "-n":
                        if (++i < length) {
                            searchPattern = args[i];
                        }
                        break;
                    default:
                        if (Directory.Exists(args[i])) {
                            if (string.IsNullOrWhiteSpace(dirPath)) dirPath = args[i];
                            else Console.WriteLine($"Already set Path: {dirPath}");
                        } else {
                            Console.WriteLine($"Not support argument (or directory not existed): {args[i]}");
                            return;
                        }
                        break;
                }
            }
            if (string.IsNullOrWhiteSpace(dirPath)) dirPath = Environment.CurrentDirectory;
            if (string.IsNullOrWhiteSpace(searchPattern)) searchPattern = "*";
            OnList(Console.Out, dirPath, searchPattern, option, fullPath, ext);
        }
        private static void OnList(TextWriter writer, string path, string searchPattern, SearchOption option, bool fullPath, bool ext) {
            var dir = new DirectoryInfo(path);
            var files = dir.GetFiles(searchPattern, option);
            var length = files.Length;
            for (int i = 0; i < length; i++) {
                var file = files[i];
                if (fullPath) writer.WriteLine(file.FullName);
                else if (ext) writer.WriteLine(file.Name);
                else writer.WriteLine(Path.GetFileNameWithoutExtension(file.Name));
            }
        }
        private static void Help() {
            Console.WriteLine();
            Console.WriteLine("Usage: ls ([option])* [searchFolder] [-n searchPattern]");
            Console.WriteLine("Where: option");
            Console.WriteLine("   -r: recruise ");
            Console.WriteLine("   -x: no extension");
            Console.WriteLine("   -f: full name");
            Console.WriteLine();
            Console.WriteLine("Where: missing searchFolder");
            Console.WriteLine("     : list on current folder");
            Console.WriteLine();
            Console.WriteLine("Where: missing searchPattern");
            Console.WriteLine("     : list all");
        }
    }
}
