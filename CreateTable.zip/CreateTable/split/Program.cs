﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace split {
    internal class Program {
        static void Main(string[] args) {
            if (args.Length == 0 || (args.Length == 1 && args[0].ToLower() == "-h")) {
                if (args.Length == 0) Console.WriteLine("Missing arguments.");
                Help();
                return;
            }
            Split(args);
        }

        static void Split(string[] args) {
            if (args.Length == 0 || (args.Length == 1 && args[0].ToLower() == "-h")) {
                if (args.Length == 0) Console.WriteLine("Missing arguments.");
                Help();
                return;
            }

            string filePath = args[0];
            if (!File.Exists(filePath)) {
                Console.WriteLine($"File not existed: {filePath}");
                return;
            }

            long maxCount = 0;
            string outPath = null;
            if (args.Length >= 2 && long.TryParse(args[1], out long v)) {
                maxCount = v;
            } else {
                var length = args.Length;
                for (int i = 1; i < length; i++) {
                    var arg = args[i];
                    switch (arg) {
                        case "-m":
                            if (maxCount > 0) {
                                Console.WriteLine($"Duplicate args: {arg}");
                                return;
                            }
                            if (long.TryParse(arg, out long l)) {
                                maxCount = l;
                            } else {
                                Console.WriteLine($"Invalid max count value: {arg}");
                                return;
                            }
                            break;
                        case "-o":
                            if (!string.IsNullOrWhiteSpace(outPath)) {
                                Console.WriteLine($"Duplicate args: {arg}");
                                return;
                            }
                            if (++i >= length) {
                                Console.WriteLine($"Output path required!");
                                return;
                            }
                            outPath = args[i];
                            break;
                        default:
                            Console.WriteLine($"Not support argument: {args[i]}");
                            return;
                    }
                }
            }
            if (maxCount <= 10) {
                Console.WriteLine($"Invalid max count:{maxCount}");
                
            }
            if (string.IsNullOrWhiteSpace(outPath)) outPath = Path.GetDirectoryName(filePath);
            else if (!Directory.Exists(outPath)) Directory.CreateDirectory(outPath);
            OnSplit(Console.Out, filePath, outPath, maxCount);
        }
        static void OnSplit(TextWriter output, string filePath, string outputPath, long maxCount) {
            var fileName = Path.GetFileName(filePath);
            int fIndex = 1;
            using (var reader = File.OpenText(filePath)) {
                string txt;
                TextWriter writer = null;
                var i = 0;
                while ((txt = reader.ReadLine()) != null) {
                    if (i == 0) {
                        var ofName = $"{fileName}.{fIndex.ToString().PadLeft(3, '0')}";
                        writer = File.CreateText(Path.Combine(outputPath, ofName));
                        if (fIndex > 1) output.WriteLine();
                        output.Write(ofName);
                    } else writer.WriteLine();

                    writer.Write(txt);
                    
                    if (++i >= maxCount) {
                        writer.Flush();
                        writer.Dispose();
                        writer = null;
                        i = 0;
                        fIndex++;
                    }
                }
                if (writer != null) {
                    writer.Flush();
                    writer.Dispose();
                }
            }
        }
        private static void Help() {
            Console.WriteLine();
            Console.WriteLine("Usage 1: split <file> <maxLine>");
            Console.WriteLine("Usage 2: split <file> [-m maxLine] [-o outputFolder]");
        }
    }
}
