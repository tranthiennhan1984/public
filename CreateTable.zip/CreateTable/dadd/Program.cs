﻿using Binean.Command;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Binean {
    internal class Program {
        static void Main() {
            var args = Host.Arguments;
            RegisterArgs(args);
            //args.ReadEnv();
            Process(args);
        }

        private static void Process(Arguments args) {
            var output = args.GetTextArg("outputPath", true);
            if (Directory.Exists(output)) Directory.Delete(output, true);
            Directory.CreateDirectory(output);

            var splitPattern = args.GetPatternArg("splitPattern", true);
            var namePattern = args.GetPatternArg("on", true);

            using (var reader = args.GetInput()) {
                var nameSet = new DependSet(reader);
                string splitName = null;
                TextWriter writer = null;

                int splitIndex = 0;
                while (reader.MoveNext()) {
                    var sn = splitPattern.Read(reader);
                    if (sn != splitName) {
                        splitName = sn;
                        nameSet[nameof(splitName)] = splitName;
                        nameSet[nameof(splitIndex)] = ++splitIndex;
                        if (writer != null) {
                            writer.Dispose();
                            writer = null;
                        }
                        var filePath = Path.Combine(output, namePattern.Read(nameSet));
                        writer = File.CreateText(filePath);
                    }
                    var length = reader.Values.Length;
                    for (int i = 0; i < length; i++) {
                        var value = reader.Values[i];
                        if (i > 0) writer.Write(',');
                        //writer.Write(value.CsvEscape());
                    }
                    writer.WriteLine();
                }
                if (writer != null) {
                    writer.Dispose();
                }
            }
        }



        private static void RegisterArgs(Arguments args) {
            args.RegisterInputArgs()
                .Register("outputPath", "Output file path");
                //.RegisterColumnsArg();
        }
    }
}

