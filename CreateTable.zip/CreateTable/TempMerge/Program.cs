﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TempMerge {
    internal class Program {
        static void Main(string[] args) {
            if (args.Length == 0 || (args.Length == 1 && args[0].ToLower() == "-h")) {
                if (args.Length == 0) Console.WriteLine("Missing arguments.");
                Help();
                return;
            }

            var inputFile = args[0];
            var outputFile = args[1];
            var tempFile = args[2];
            var hasHeader = args.Length > 3 && args[3] == "Y";

            if (Directory.Exists(outputFile)) WriteFolder(inputFile, outputFile, tempFile, hasHeader);
            else WriteFile(inputFile, outputFile, tempFile, hasHeader);
        }

        private static void WriteFolder(string inputFile, string outputFolder, string tempFile, bool hasHeader) {
            using (var input = File.OpenText(inputFile)) {
                var csvReader = new CsvReader(input, hasHeader);
                var context = new CsvContext(csvReader);
                var temp = new Template(File.ReadAllText(tempFile));
                while (csvReader.Next()) {
                    var name = csvReader.Values[0];
                    var outputFile = Path.Combine(outputFolder, name);
                    using (var output = File.CreateText(outputFile)) {
                        temp.Write(output, context);
                    }
                }
            }
        }
        private static void WriteFile(string inputFile, string outputFile, string tempFile, bool hasHeader) {
            using (var input = File.OpenText(inputFile)) {
                var csvReader = new CsvReader(input, hasHeader);
                var context = new CsvContext(csvReader);
                var temp = new Template(File.ReadAllText(tempFile));
                using (var output = File.CreateText(outputFile)) {
                    while (csvReader.Next()) {
                        temp.Write(output, context);
                    }
                }
            }
        }

        private static void Help() {
            Console.WriteLine();
            Console.WriteLine("Usage: template <input> <output> <template> [hasHeader]");
            Console.WriteLine("Where: hasHeader");
            Console.WriteLine("     - Y     : Has Header");
            Console.WriteLine("     - Other : No Header");
        }
    }

    internal class Template {
        readonly List<IEntry> _entries = new List<IEntry>();
        public Template(string template) {
            using (var reader = new StringReader(template))
                Parse(reader);
        }
        private void Parse(TextReader reader) {
            var sb = new StringBuilder();
            char varChr = ' ';
            var isEscape = false;
            int value;
            while ((value = reader.Peek()) > 0) {
                var chr = (char)value;

                if (varChr != ' ') {
                    if (char.IsLetterOrDigit(chr) || chr == '_') {
                        sb.Append(chr);
                        reader.Read();
                    } else {
                        _entries.Add(
                            varChr == '@' ? (IEntry)new VarEntry(sb.ToString())
                            : new EnvEntry(sb.ToString()));
                        if (chr == varChr) reader.Read();
                        sb.Clear();
                        varChr = ' ';
                    }
                    continue;
                }

                if (isEscape) {
                    isEscape = false;
                    var index = "rnt".IndexOf(chr);
                    if (index < 0) sb.Append(chr);
                    else sb.Append("\r\n\t"[index]);
                    reader.Read();
                    continue;
                }
                if (chr == '\\') {
                    isEscape = true;
                    reader.Read();
                    continue;
                }
                const string varchars = "@$";
                var vIndex = varchars.IndexOf(chr);
                if (vIndex > -1) {
                    _entries.Add(new TextEntry(sb.ToString()));
                    sb.Clear();
                    reader.Read();
                    varChr = varchars[vIndex];
                    continue;
                }
                sb.Append(chr);
                reader.Read();
            }
            if (sb.Length > 0) {
                if (varChr == '@') _entries.Add(new VarEntry(sb.ToString()));
                else if (varChr == '$') _entries.Add(new EnvEntry(sb.ToString()));
                else _entries.Add(new TextEntry(sb.ToString()));
            }
        }
        public void Write(StreamWriter writer, IDataContext context) {
            var length = _entries.Count;
            for (int i = 0; i < length; i++) {
                var entry = _entries[i];
                entry.Write(writer, context);
            }
        }
    }

    interface IDataContext {
        bool TryGetValue(string name, out string value);
    }
    internal class CsvContext : IDataContext {
        readonly CsvReader _reader;
        public CsvContext(CsvReader reader) {
            _reader = reader;
        }
        public bool TryGetValue(string name, out string value) {
            if (string.IsNullOrEmpty(name) || _reader.Values == null) {
                value = null;
                return false;
            }

            var index = -1;
            if (_reader.HasHeader) {
                if (_reader.Names == null) {
                    value = null;
                    return false;
                }
                var length = _reader.Names.Length;
                for (int i = 0; i < length; i++) {
                    if (_reader.Names[i] == name) {
                        index = i;
                        break;
                    }
                }
            } else if (int.TryParse(name, out int intValue)) {
                index = intValue;
            }

            if (index < 0) {
                value = null;
                return false;
            }

            value = _reader.Values[index];
            return true;
        }
    }

    internal interface IEntry {
        void Write(StreamWriter writer, IDataContext context);
    }
    internal class TextEntry : IEntry {
        public TextEntry(string text) {
            Text = text;
        }

        public string Text { get; }
        public void Write(StreamWriter writer, IDataContext context) {
            if (string.IsNullOrEmpty(Text)) return;
            writer.Write(Text);
        }
    }
    internal sealed class VarEntry : IEntry {
        public VarEntry(string name) {
            Name = name;
        }
        public string Name { get; }
        public void Write(StreamWriter writer, IDataContext context) {
            if (string.IsNullOrEmpty(Name)) throw new InvalidDataException(Name);
            if (!context.TryGetValue(Name, out string value)) throw new InvalidDataException(Name);
            if (!string.IsNullOrEmpty(value)) writer.Write(value);
        }
    }
    internal sealed class EnvEntry : IEntry {
        public EnvEntry(string name) {
            Name = name;
        }
        public string Name { get; }
        public void Write(StreamWriter writer, IDataContext context) {
            if (string.IsNullOrEmpty(Name)) throw new InvalidDataException(Name);
            var value = Environment.GetEnvironmentVariable(Name);
            if (value == null) throw new InvalidDataException(Name);
            if (!string.IsNullOrEmpty(value)) writer.Write(value);
        }
    }
}