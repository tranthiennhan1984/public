﻿using System.Collections.Generic;
using System.IO;
using System.Text;
namespace TempMerge {
    internal class CsvReader {
        readonly StreamReader _reader;
        public CsvReader(StreamReader reader, bool hasHeader = false) {
            _reader = reader;
            if (HasHeader = hasHeader) Names = ReadLine();
        }

        public bool HasHeader { get; }
        public string[] Names { get; }
        public string[] Values { get; private set; }

        private string[] ReadLine() {
            var retVal = new List<string>();
            string txt = null;
            int value;
            while ((value = _reader.Peek()) > 0) {
                var chr = (char)value;
                if (chr == '\r') {
                    _reader.Read();
                    if (_reader.Peek() != '\n') {
                        retVal.Add(txt);
                        break;
                    }
                    continue;
                }
                if (chr == '\n') {
                    retVal.Add(txt);
                    _reader.Read();
                    break;
                }
                if (chr == ',') {
                    _reader.Read();
                    retVal.Add(txt);
                    txt = null;
                    continue;
                }
                txt = ReadString();
            }
            if (value < 0 && (txt != null || retVal.Count > 0)) retVal.Add(txt);
            return retVal.ToArray();
        }
        private string ReadString() {
            var retVal = new StringBuilder();
            int value = _reader.Peek();
            if (value == 0) return null;
            var chr = (char)value;

            var escChar = "\"'".IndexOf(chr) < 0 ? ' ' : chr;
            if (escChar != ' ') _reader.Read();

            while ((value = _reader.Peek()) > 0) {
                chr = (char)value;
                if (escChar != ' ') {
                    _reader.Read();
                    if (chr == escChar) {
                        if ((value = _reader.Peek()) > 0 && ((char)value) == escChar) {
                            _reader.Read();
                            retVal.Append(escChar);
                            continue;
                        }
                        break;
                    }
                    retVal.Append(chr);
                    continue;
                }
                if (",\r\n".IndexOf(chr) >= 0) break;
                retVal.Append(chr);
                _reader.Read();
            }
            if (retVal.Length == 0) return escChar != ' ' ? string.Empty : null;
            return retVal.ToString();
        }
        public bool Next() {
            Values = ReadLine();
            return Values.Length > 0;
        }
    }
}
