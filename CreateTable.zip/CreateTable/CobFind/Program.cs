﻿using Binean.Command;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Binean {
    internal sealed class Program {
        static void Main() {
            var debug = Environment.GetEnvironmentVariable("CMD_DEBUG")?.ToUpper();
            //if (debug == "Y")System.Diagnostics.Debugger.Launch();

            var args = Host.Arguments;
            args.ClearUsage();
            RegisterArgs(args);
            args.Read(Environment.GetCommandLineArgs());

            Process(args);
        }

        private static void Process(Arguments args) {
            var input = args.GetArg("inputFolder", true).CastAs<string>();
            var output = args.GetArg("outputFolder", true).CastAs<string>();
            var txt = args.GetArg("text", true).CastAs<string>();
            var filters = args.GetArg("f", true).CastAs<string>();
            var prompt = args.GetArg("p", false).CastAs<bool>();

            var stype = "text";
            var search = new Func<string, string, int>(FindText);
            if (args.GetArg("r").CastAs<bool>()) {
                stype = "remark";
                search = FindRemark;
            } else if (args.GetArg("c").CastAs<bool>()) {
                stype = "code";
                search = FindCode;
            }

            if (!Directory.Exists(input)) {
                Console.Out.WriteLine($"Input folder doesn't exist {input}");
                return;
            }
            if (string.IsNullOrEmpty(output)) {
                Console.Out.WriteLine($"Missing output {output}");
                return;
            }
            if (string.IsNullOrEmpty(Directory.GetDirectoryRoot(output))) {
                Console.Out.WriteLine($"Invalid output {output}");
                return;
            }
            if (string.IsNullOrEmpty(txt)) {
                Console.Out.WriteLine("Missing Work unit");
                return;
            }

            Console.Out.WriteLine($"\"Find {stype} {txt} on {input}\"");
            Process(input, output, output, txt, filters, prompt, search);
        }
        private static void Process(string input, string baseOutput, string output, string txt, string filters, bool prompt, Func<string, string, int> search) {
            if (!Directory.Exists(output)) Directory.CreateDirectory(output);
            foreach (var item in Directory.GetDirectories(input)) {
                var name = Path.GetFileName(item);
                Process(Path.Combine(input, name), baseOutput, Path.Combine(output, name), txt, filters, prompt, search);
            }
            var fils = filters.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);

            var length = fils.Length;
            for (int i = 0; i < length; i++) {
                foreach (var file in Directory.GetFiles(input, fils[i], SearchOption.TopDirectoryOnly)) {
                    var name = Path.GetFileName(file);
                    var oFile = Path.Combine(output, name);
                    using (var reader = File.OpenText(file)) {
                        using (var writer = File.CreateText(oFile)) {
                            string line;
                            while ((line = reader.ReadLine()) != null) {
                                var index = search(line, txt);
                                if (index == -1) continue;
                                writer.WriteLine(line);
                            }
                        }
                    }
                    var fin = new FileInfo(oFile);
                    if (fin.Exists && fin.Length == 0) {
                        File.Delete(oFile);
                        continue;
                    }
                    if (prompt && fin.Exists) {
                        Console.Out.Write(",");
                        var p = GetRelative(baseOutput, oFile);
                        Console.Write($"\"{Path.GetDirectoryName(p)}\"");
                        Console.Out.Write(",");
                        Console.Write($"\"{Path.GetFileName(p)}\"");
                        Console.Out.Write(",");
                        Console.WriteLine($"\"{Path.GetFileNameWithoutExtension(p)}\"");
                    }
                }
            }
            var folder = new DirectoryInfo(output);
            if (folder.Exists && folder.GetFileSystemInfos().Length == 0) Directory.Delete(output);
        }
        private static int FindRemark(string line, string txt)
            => line.StartsWith(txt) ? 0 : -1;
        private static int FindCode(string line, string txt) {
            if (string.IsNullOrEmpty(line)) return -1;
            if (line.Length < 7 || "*/".IndexOf(line[6]) > -1) return -1;

            var index = line.IndexOf(txt);
            if (index < 0) return -1;

            var end = index + txt.Length;
            if (index <= 6 || end > 72) return -1;

            if (!char.IsWhiteSpace(line[index - 1])) return -1;
            if (end < line.Length) {
                var chr = line[end];
                if (chr == '-' || char.IsLetterOrDigit(chr)) return -1;
            }
            return index;
        }
        private static int FindText(string line, string txt) {
            if (string.IsNullOrEmpty(line)) return -1;
            return line.IndexOf(txt);
        }
        private static string GetRelative(string basePath, string path) {
            return "\\" + path.Replace(basePath, "").TrimStart('\\');
        }

        private static void RegisterArgs(Arguments args) {
            args.Register("inputFolder", "Input folder")
                .Register("outputFolder", "Output folder")
                .Register("text", "Search text")
                .RegisterOptions("f", "File filters separate with ;", null, "*.cbl;*.cpy;*.ccp;")
                .RegisterOptions("r", "Search remark (work unit)", null, false)
                .RegisterOptions("c", "Search code; exclude comment line", null, false)
                .RegisterOptions("p", "Print result", null, true);
        }
    }
}

