﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace join {
    internal class Program {
        static void Main(string[] args) {
            if (args.Length == 0 || (args.Length == 1 && args[0].ToLower() == "-h")) {
                if (args.Length == 0) Console.WriteLine("Missing arguments.");
                Help();
                return;
            }
            Join(args);
        }

        static void Join(string[] args) {
            var files = new List<string>();

            string outPath = null;
            var appendNewLine = false;
            var deleteFiles = false;
            var length = args.Length;
            for (int i = 0; i < length; i++) {
                var arg = args[i];
                switch (arg) {
                    case "-o":
                        if (!string.IsNullOrWhiteSpace(outPath)) {
                            Console.WriteLine($"Duplicate args: {arg}");
                            return;
                        }
                        if (++i >= length) {
                            Console.WriteLine($"Output path required!");
                            return;
                        }
                        outPath = args[i];
                        break;
                    case "-d":
                        deleteFiles = true;
                        break;
                    case "-n":
                        appendNewLine = true;
                        break;
                    default:
                        if (!File.Exists(arg)) {
                            Console.WriteLine($"File not existed:{arg}");
                            return;
                        }
                        files.Add(arg);
                        break;
                }
            }

            if (files.Count == 0) {
                Console.WriteLine($"No file not to join");
                return;
            }
            if (files.Count == 1) {
                var file = files[0];
                var ext = Path.GetExtension(file);
                if (ext == ".001") {
                    file = Path.Combine(Path.GetDirectoryName(file), Path.GetFileNameWithoutExtension(file));
                    if (string.IsNullOrWhiteSpace(outPath)) outPath = file;
                    var index = 1;
                    string next;
                    while (File.Exists(next = Path.Combine(file, (++index).ToString().PadLeft(3, '0'))))
                        files.Add(next);
                }
            }
            if (string.IsNullOrWhiteSpace(outPath)) {
                Console.WriteLine($"Missing output path");
                return;
            }
            var outDir = Path.GetDirectoryName(outPath);
            if (!Directory.Exists(outDir)) Directory.CreateDirectory(outDir);

            OnJoin(files, outPath, appendNewLine, deleteFiles);
        }
        static void OnJoin(List<string> files, string outPath, bool appendNewLine, bool deleteFiles) {
            var length = files.Count;
            using (var writer = File.CreateText(outPath)) {
                for (int i = 0; i < length; i++) {
                    var file = files[i];
                    if (appendNewLine && i > 0) writer.WriteLine();
                    writer.Write(File.ReadAllText(file));
                }
            }

            if (!deleteFiles) return;
            for (int i = 0; i < length; i++) {
                File.Delete(files[i]);
            }
        }

        private static void Help() {
            Console.WriteLine();
            Console.WriteLine("Usage 1: join <filePath.001> [-o outputPath] [option] * ");
            Console.WriteLine("       : Join all file with extension from .001 to .ddd continually");
            Console.WriteLine("       : If missing outputPath, it will be filePath (without ext .001)");
            Console.WriteLine();
            Console.WriteLine("Where  : option");
            Console.WriteLine("    - d: Delete files after join completed");
            Console.WriteLine("    - n: Append new line at begin of each file");
            Console.WriteLine();
            Console.WriteLine("Usage 2: join [-o outputPath] [option] <filePath>*");
            Console.WriteLine("       : Join all files in list");
            Console.WriteLine("Where  : option");
            Console.WriteLine("    - d: Delete files after join completed");
            Console.WriteLine("    - n: Append new line at begin of each file");
            Console.WriteLine();
        }
    }
}
