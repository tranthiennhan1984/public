﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Markup;

namespace CreateReference {
    internal class Program {
        static void Main(string[] args) {
            var cmdFolder = args[0];
            var inputFolder = args[1];
            var ddlFolder = args[2];

            if (!Directory.Exists(inputFolder)) return;
            if (!Directory.Exists(cmdFolder)) Directory.CreateDirectory(cmdFolder);

            if (!Directory.Exists(ddlFolder)) Directory.CreateDirectory(ddlFolder);

            var endInfo = EnvInfo.Instance;

            var tables = new Dictionary<string, Table>();
            string tName = null;
            Table t = null;

            var refs = Path.Combine(inputFolder, "references.csv");
            using (var reader = File.OpenText(refs)) {
                var csvReader = new CsvReader(reader, false);
                while (csvReader.Next()) {
                    var tn = $"{csvReader.Values[1].Trim().ToUpper()}.{csvReader.Values[2].Trim().ToUpper()}";
                    if (tn != tName) {
                        tName = tn;
                        t = new Table {
                            Schema = csvReader.Values[1].Trim(),
                            Name = csvReader.Values[2].Trim(),
                        };
                        tables[tn] = t;
                    }

                    t.References.Add(new Reference {
                        Name = csvReader.Values[0].Trim(),
                        TabSchema = csvReader.Values[1].Trim(),
                        TabName = csvReader.Values[2].Trim(),
                        RefKeyName = csvReader.Values[3].Trim(),
                        RefTabSchema = csvReader.Values[4].Trim(),
                        RefTabName = csvReader.Values[5].Trim(),
                        ColCount = intParse(csvReader.Values[6].Trim()),
                        DeleteRule = csvReader.Values[7].Trim(),
                        UpdateRule = csvReader.Values[8].Trim(),
                        FK_ColNames = csvReader.Values[9].Trim(),
                        PK_ColNames = csvReader.Values[10].Trim(),
                    }); ;
                }
            }

            ////UPDATE INDEX NAME

            //foreach (var key in tables.Keys) {
            //    var table = tables[key];
            //    var inds = table.Indexes;
            //    var length = inds.Count;
            //    for (int i = 0; i < length; i++) {
            //        var ind = inds[i];
            //        ind.Name = $"X{(i + 1).ToString().PadLeft(2, '0')}{table.Name.Substring(1)}";
            //    }

            //}

            var cmdF = Path.Combine(cmdFolder, $"05_CreateReferences.bat");
            //var cmdL = Path.Combine(cmdFolder, $"createReferences.log");
            using (var cmdWriter = File.CreateText(cmdF)) {
                //cmdWriter.WriteLine($"call \"{Path.Combine(cmdFolder, "setenv.bat")}\"");
                //cmdWriter.WriteLine($"db2 connect to {endInfo.DbName} user {endInfo.DbUser} using {endInfo.DbPass} > \"{cmdL}\"");
                //cmdWriter.WriteLine($"db2 SET SCHEMA {endInfo.DbSchema} >> \"{cmdL}\"");
                cmdWriter.WriteLine($"call setenv.bat");
                cmdWriter.WriteLine($"db2 connect to %DBNAME% user %DBUSER% using %DBPASS% > \"%FdCmd%\\createReferences.log\"");
                cmdWriter.WriteLine($"db2 SET SCHEMA %DBSCHEMA% >> \"%FdCmd%\\createReferences.log\"");
                foreach (var key in tables.Keys) {
                    var table = tables[key];
                    var of = Path.Combine(ddlFolder, $"FK{table.Name}.sql");
                    cmdWriter.WriteLine($"db2 -tvmf %FdDdl%\\FK{table.Name}.sql >> \"%FdCmd%\\createReferences.log\"");
                    using (var writer = File.CreateText(of)) {
                        CreateReference(writer, table);
                    }
                }
                cmdWriter.WriteLine($"db2 terminate");
            }

            //Drop references
            var cmdE = Path.Combine(cmdFolder, $"dropReferences.bat");
            //cmdL = Path.Combine(cmdFolder, $"dropReferences.log");
            using (var cmdWriter = File.CreateText(cmdE)) {
                //cmdWriter.WriteLine($"call \"{Path.Combine(cmdFolder, "setenv.bat")}\"");
                //cmdWriter.WriteLine($"db2 connect to {endInfo.DbName} user {endInfo.DbUser} using {endInfo.DbPass} > \"{cmdL}\"");
                //cmdWriter.WriteLine($"db2 SET SCHEMA {endInfo.DbSchema} >> \"{cmdL}\"");
                cmdWriter.WriteLine($"call setenv.bat");
                cmdWriter.WriteLine($"db2 connect to %DBNAME% user %DBUSER% using %DBPASS% > \"%FdCmd%\\dropReferences.log\"");
                cmdWriter.WriteLine($"db2 SET SCHEMA %DBSCHEMA% >> \"%FdCmd%\\dropReferences.log\"");
                foreach (var key in tables.Keys) {
                    var table = tables[key];
                    var of = Path.Combine(ddlFolder, $"DF{table.Name}.sql");
                    cmdWriter.WriteLine($"db2 -tvmf %FdDdl%\\DF{table.Name}.sql >> \"%FdCmd%\\dropReferences.log\"");
                    using (var writer = File.CreateText(of)) {
                        DropReference(writer, table);
                    }
                }
                cmdWriter.WriteLine($"db2 terminate");
            }
        }
        static int intParse(string txt, int faultValue = -1) {
            if (string.IsNullOrWhiteSpace(txt)) return faultValue;
            if (!double.TryParse(txt, out double v)) return faultValue;
            return (int)v;
        }

        static void CreateReference(StreamWriter writer, Table table) {
            writer.WriteLine($"-- THE FOLLOWING SQL IS USED TO DEFINE EACH");
            writer.WriteLine($"-- FOREIGN KEY FOR THE TABLE: {table.Name}");
            writer.WriteLine($"-- *****************************************************************");
            writer.WriteLine($"-- ALTER TABLE");
            writer.WriteLine($"-- *****************************************************************");

            var refs = table.References;
            var length = refs.Count;
            for (int i = 0; i < length; i++) {
                var r = refs[i];

                writer.WriteLine($"ALTER TABLE {table.Name}");
                writer.WriteLine($"  ADD CONSTRAINT {r.Name} FOREIGN KEY");
                writer.Write("      (");
                WriteColumn(writer, r.FK_ColNames);
                writer.WriteLine(")");
                writer.WriteLine($"       REFERENCES {r.RefTabName}");
                writer.Write("      (");
                WriteColumn(writer, r.PK_ColNames);
                writer.Write(")");

                if (r.DeleteRule == "R") {
                    writer.WriteLine();
                    writer.Write("       ON DELETE RESTRICT");
                } else if (r.DeleteRule == "C") {
                    writer.WriteLine();
                    writer.Write("       ON DELETE CASCADE");
                }
                writer.WriteLine(";");
            }
        }


        static void DropReference(StreamWriter writer, Table table) {
            writer.WriteLine($"-- THE FOLLOWING SQL IS USED TO DROP EACH");
            writer.WriteLine($"-- FOREIGN KEY FOR THE TABLE: {table.Name}");
            writer.WriteLine($"-- *****************************************************************");
            writer.WriteLine($"-- ALTER TABLE");
            writer.WriteLine($"-- *****************************************************************");

            var refs = table.References;
            var length = refs.Count;
            for (int i = 0; i < length; i++) {
                var r = refs[i];
                writer.WriteLine($"ALTER TABLE {table.Name}");
                writer.WriteLine($"  DROP FOREIGN KEY {r.Name};");
            }
        }
        static void WriteColumn(StreamWriter writer, string column) {
            var i = -1;
            using (var reader = new StringReader(column)) {
                while (ReadColumn(reader, out string name)) {
                    if (++i > 0) {
                        writer.WriteLine(",");
                        writer.Write("       ");
                    }
                    writer.Write(name);
                }
            }
        }
        static bool ReadColumn(TextReader reader, out string name) {
            var sb = new StringBuilder();
            var step = 0;
            char chr;
            while ((chr = Peek(reader)) != EOF) {
                if (step == 0) {
                    if (char.IsWhiteSpace(chr)) reader.Read();
                    else step = 1;
                    continue;
                }

                if (char.IsWhiteSpace(chr)) break;
                sb.Append(chr);
                reader.Read();
                continue;
            }
            name = sb.ToString().Trim();
            return !string.IsNullOrEmpty(name);
        }

        const char EOF = '\0';
        static char Peek(TextReader reader) {
            var v = reader.Peek();
            if (v <= 0) return EOF;
            return (char)v;
        }
    }

    class EnvInfo {
        public static EnvInfo Instance = new EnvInfo();
        private EnvInfo() {
            DbName = GetVar("DBNAME", "UDIPPV26");
            DbSchema = GetVar("DBSCHEMA", "IPPV26");
            DbUser = GetVar("DBUSER", "IPPV26");
            DbPass = GetVar("DBPASS", "vnutd3v");
            ExportFolder = GetVar("FdData", "D:\\ING\\Data");
        }

        public string DbName { get; }
        public string DbSchema { get; }
        public string DbUser { get; }
        public string DbPass { get; }

        public string ExportFolder { get; }

        private static string GetVar(string name, string defaultValue)
            => Environment.GetEnvironmentVariable(name) ?? defaultValue;
    }

    class Table {
        public string Schema { get; set; }
        public string Name { get; set; }
        public List<Reference> References { get; } = new List<Reference>();
    }

    class Reference {
        public string Name { get; set; }
        public string TabSchema { get; set; }
        public string TabName { get; set; }
        public string RefKeyName { get; set; }
        public string RefTabSchema { get; set; }
        public string RefTabName { get; set; }
        public int ColCount { get; set; }
        public string DeleteRule { get; set; }
        public string UpdateRule { get; set; }
        public string FK_ColNames { get; set; }
        public string PK_ColNames { get; set; }
    }
}
