﻿using System.Collections;
using System.Collections.Generic;

namespace Binean {
    interface IDataContext {
        bool TryGetValue(string name, out string value);
    }
    internal class CsvContext : IDataContext {
        readonly CsvReader _reader;
        public CsvContext(CsvReader reader) {
            _reader = reader;
        }
        public bool TryGetValue(string name, out string value) {
            if (string.IsNullOrEmpty(name) || _reader.Values == null) {
                value = null;
                return false;
            }

            var index = -1;
            if (_reader.HasHeader) {
                if (_reader.Names == null) {
                    value = null;
                    return false;
                }
                var length = _reader.Names.Length;
                for (int i = 0; i < length; i++) {
                    if (_reader.Names[i] == name) {
                        index = i;
                        break;
                    }
                }
            } else if (int.TryParse(name, out int intValue)) {
                index = intValue;
            }

            if (index < 0) {
                value = null;
                return false;
            }

            value = _reader.Values[index];
            return true;
        }
    }
    internal class DataContext : IDataContext {
        readonly IDictionary<string, string> _dic;
        public DataContext(IDictionary<string, string> dic) {
            _dic = dic;
        }
        public bool TryGetValue(string name, out string value)
            => _dic.TryGetValue(name, out value);
    }
}
