﻿using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Binean {
    internal class Program {
        static void Main(string[] args) {
            if (args.Length == 0 || (args.Length == 1 && args[0].ToLower() == "-h")) {
                if (args.Length == 0) Console.WriteLine("Missing arguments.");
                Help();
                return;
            }

            var inputFile = args[0];
            var outputFile = args[1];
            var tempFile = args[2];
            var hasHeader = args.Length > 3 && args[3] == "Y";

            if (Directory.Exists(outputFile)) WriteFolder(inputFile, outputFile, tempFile, hasHeader);
            else WriteFile(inputFile, outputFile, tempFile, hasHeader);
        }

        private static void WriteFolder(string inputFile, string outputFolder, string tempFile, bool hasHeader) {
            using (var input = File.OpenText(inputFile)) {
                var csvReader = new CsvReader(input, hasHeader);
                var context = new CsvContext(csvReader);
                var temp = new Template(File.ReadAllText(tempFile));
                while (csvReader.Next()) {
                    var name = csvReader.Values[0];
                    var outputFile = Path.Combine(outputFolder, name);
                    using (var output = File.CreateText(outputFile)) {
                        temp.Write(output, context);
                    }
                }
            }
        }
        private static void WriteFile(string inputFile, string outputFile, string tempFile, bool hasHeader) {
            using (var input = File.OpenText(inputFile)) {
                var csvReader = new CsvReader(input, hasHeader);
                var context = new CsvContext(csvReader);
                var temp = new Template(File.ReadAllText(tempFile));
                using (var output = File.CreateText(outputFile)) {
                    while (csvReader.Next()) {
                        temp.Write(output, context);
                    }
                }
            }
        }

        private static void Help() {
            Console.WriteLine();
            Console.WriteLine("Usage: template <input> <output> <template> [hasHeader]");
            Console.WriteLine("Where: hasHeader");
            Console.WriteLine("     - Y     : Has Header");
            Console.WriteLine("     - Other : No Header");
        }
    }
}
