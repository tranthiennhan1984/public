﻿using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Binean {
    internal class Template {
        readonly List<IEntry> _entries = new List<IEntry>();
        public Template(string template) {
            using (var reader = new StringReader(template))
                Parse(reader);
        }
        private void Parse(TextReader reader) {
            var sb = new StringBuilder();
            char varChr = ' ';
            var isEscape = false;
            int value;
            while ((value = reader.Peek()) > 0) {
                var chr = (char)value;

                if (varChr != ' ') {
                    if (char.IsLetterOrDigit(chr) || chr == '_') {
                        sb.Append(chr);
                        reader.Read();
                    } else {
                        _entries.Add(
                            varChr == '@' ? (IEntry)new VarEntry(sb.ToString())
                            : new EnvEntry(sb.ToString()));
                        if (chr == varChr) reader.Read();
                        sb.Clear();
                        varChr = ' ';
                    }
                    continue;
                }

                if (isEscape) {
                    isEscape = false;
                    var index = "rnt".IndexOf(chr);
                    if (index < 0) sb.Append(chr);
                    else sb.Append("\r\n\t"[index]);
                    reader.Read();
                    continue;
                }
                if (chr == '\\') {
                    isEscape = true;
                    reader.Read();
                    continue;
                }
                const string varchars = "@$";
                var vIndex = varchars.IndexOf(chr);
                if (vIndex > -1) {
                    _entries.Add(new TextEntry(sb.ToString()));
                    sb.Clear();
                    reader.Read();
                    varChr = varchars[vIndex];
                    continue;
                }
                sb.Append(chr);
                reader.Read();
            }
            if (sb.Length > 0) {
                if (varChr == '@') _entries.Add(new VarEntry(sb.ToString()));
                else if (varChr == '$') _entries.Add(new EnvEntry(sb.ToString()));
                else _entries.Add(new TextEntry(sb.ToString()));
            }
        }
        public void Write(StreamWriter writer, IDataContext context) {
            var length = _entries.Count;
            for (int i = 0; i < length; i++) {
                var entry = _entries[i];
                entry.Write(writer, context);
            }
        }
    }
}
