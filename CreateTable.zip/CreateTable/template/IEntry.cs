﻿using System;
using System.IO;

namespace Binean {
    internal interface IEntry {
        void Write(StreamWriter writer, IDataContext context);
    }
    internal class TextEntry : IEntry {
        public TextEntry(string text) {
            Text = text;
        }

        public string Text { get; }
        public void Write(StreamWriter writer, IDataContext context) {
            if (string.IsNullOrEmpty(Text)) return;
            writer.Write(Text);
        }
    }
    internal sealed class VarEntry : IEntry {
        public VarEntry(string name) {
            Name = name;
        }
        public string Name { get; }
        public void Write(StreamWriter writer, IDataContext context) {
            if (string.IsNullOrEmpty(Name)) throw new InvalidDataException(Name);
            if (!context.TryGetValue(Name, out string value)) throw new InvalidDataException(Name);
            if (!string.IsNullOrEmpty(value)) writer.Write(value);
        }
    }
    internal sealed class EnvEntry : IEntry {
        public EnvEntry(string name) {
            Name = name;
        }
        public string Name { get; }
        public void Write(StreamWriter writer, IDataContext context) {
            if (string.IsNullOrEmpty(Name)) throw new InvalidDataException(Name);
            var value = Environment.GetEnvironmentVariable(Name);
            if (value == null) throw new InvalidDataException(Name);
            if (!string.IsNullOrEmpty(value)) writer.Write(value);
        }
    }
}
