﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace SplitData {
    internal class Program {
        static void Main(string[] args) {
            var to = "F:\\Softwares\\Daiichi\\ING_DAI";
            var froms = Directory.GetDirectories("F:\\Softwares\\Daiichi\\ING_UT");
            var length = froms.Length;
            for (int i = 0; i < length; i++) {
                if (!(froms[i] is string fm)) continue;
                var name = Path.GetFileNameWithoutExtension(fm);
                Process(froms[i], Path.Combine(to, name));
            }
        }
        private static void Process(string from, string to) {
            if (!Directory.Exists(to)) Directory.CreateDirectory(to);
            var files = Directory.GetFiles(from);
            var length = files.Length;
            for (int i = 0; i < length; i++) {
                if (!(files[i] is string fn)) continue;
                var name = Path.GetFileNameWithoutExtension(fn);
                var index = name.IndexOf("2021");
                if (index > 0) name = name.Substring(0, index);
                Split(fn, Path.Combine(to, name + ".sql"));
            }
        }

        private static void Split(string from, string to) {
            using (var reader = File.OpenText(from)) {
                using (var writer = File.CreateText(to)) {
                    string line;
                    while ((line = reader.ReadLine()) != null) {
                        if (line.StartsWith("INSERT INTO ")) return;
                        writer.WriteLine(line);
                    }
                }
            }
        }
    }
}
