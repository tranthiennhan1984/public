﻿using Binean.Command;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Binean {
    internal class Program {
        static void Main() {
            var debug = Environment.GetEnvironmentVariable("CMD_DEBUG")?.ToUpper();
            //if (debug == "Y") 
            System.Diagnostics.Debugger.Launch();

            RegisterMethods();

            var args = Host.Arguments;
            RegisterArgs(args);
            args.Read(Environment.GetCommandLineArgs());

            Process(args);
        }

        private static void Process(Arguments args) {
            string output = args.GetArg("outputPath", true).GetValue(Host.Empty).CastAs<string>();
            if (!Directory.Exists(output)) Directory.CreateDirectory(output);

            var splitPattern = args.GetArg("splitPattern", true).ToTemplate();
            var namePattern = args.GetArg("on").ToTemplate();

            var gNamePattern = args.GetArg("gn").ToTemplate();
            var gCols = gNamePattern == null ? null : args.BuildColumns("gcol");

            var oh = args.GetArg("oh").GetValue(Host.Empty).CastAs(false);
            var gh = args.GetArg("gh").GetValue(Host.Empty).CastAs(false);

            var cols = args.BuildColumns();

            var isFirst = true;
            using (var reader = args.GetInput()) {
                var nameSet = new DependSet(reader);
                string splitName = null;
                CsvWriter gWriter = null;
                CsvWriter csvWriter = null;
                var splitDataSet = new ItemDataSet(reader);
                var groupDataSet = new GroupDataSet(reader);

                int splitIndex = 0;
                while (reader.MoveNext()) {
                    if (isFirst) {
                        isFirst = false;
                        if (cols == null) cols = reader.GetColumns();
                        if (gNamePattern != null) {
                            if (gCols == null) gCols = reader.GetColumns();
                            var gPath = Path.Combine(output, gNamePattern.Read(reader));
                            gWriter = new CsvWriter(File.CreateText(gPath), gCols);
                            if (gh && gWriter.HasHeader) gWriter.WriteHeader();
                        }
                    }
                    if (splitPattern != null) {
                        var sn = splitPattern.Read(reader);
                        if (sn != splitName) {
                            splitName = sn;
                            groupDataSet.NextIndex();
                            gWriter?.Write(groupDataSet);

                            nameSet[nameof(splitName)] = splitName;
                            nameSet[nameof(splitIndex)] = ++splitIndex;
                            csvWriter?.Dispose();

                            if (namePattern != null) {
                                var filePath = Path.Combine(output, namePattern.Read(nameSet));
                                csvWriter = new CsvWriter(File.CreateText(filePath), cols);
                                if (oh && csvWriter.HasHeader) csvWriter.WriteHeader();
                                splitDataSet.Reset();
                                splitDataSet.GroupId = groupDataSet.RowId;
                            }
                        }
                    }
                    csvWriter?.Write(splitDataSet);
                }
                csvWriter?.Dispose();
                gWriter?.Dispose();
            }
        }

        private static void RegisterMethods() {
            new Db2TypeMethod().Register();
            new Db2OptionMethod().Register();
        }
        private static void RegisterArgs(Arguments args) {
            args.RegisterInputArgs()
                .Register("outputPath", "Output folder")
                .RegisterOptions("on", "Output file name pattern", ":pattern")
                .Register("splitPattern", "Split pattern")
                .RegisterOptions("col", "Output columns", ":colpattern", null, true)
                .RegisterOptions("oh", "Write output headers")
                .RegisterOptions("gn", "Group output file name pattern", ":pattern")
                .RegisterOptions("gh", "Write group headers")
                .RegisterOptions("gcol", "Group columns", ":colpattern", null, true);
            ;
        }
    }
    internal sealed class ItemDataSet : IDataSet {
        readonly IDataSet _dataSet;
        int _offset;
        public ItemDataSet(IDataSet dataSet) {
            _dataSet = dataSet;
            Reset();
        }
        public int RowId => _dataSet.RowId - _offset;
        public int RowNumber => _dataSet.RowNumber;
        public int GroupId {
            get { return _groupId > 0 ? _groupId : RowId == 0 ? 0 : 1; }
            set { _groupId = value; }
        }
        private int _groupId;
        public bool MoveNext() => throw new InvalidOperationException();

        public void Reset() => _offset = _dataSet.RowId;
        public bool TryGetValue(string name, out object value)
            => _dataSet.TryGetValue(name, out value);
        void IDisposable.Dispose() { }
    }
    internal sealed class GroupDataSet : IDataSet {
        readonly IDataSet _dataSet;
        public GroupDataSet(IDataSet dataSet) {
            _dataSet = dataSet;
        }
        public int RowId { get; private set; }
        public int RowNumber => _dataSet.RowNumber;
        public int GroupId {
            get { return _groupId > 0 ? _groupId : RowId == 0 ? 0 : 1; }
            set { _groupId = value; }
        }
        private int _groupId;
        public bool MoveNext() => throw new InvalidOperationException();

        public void NextIndex() => RowId++;
        public bool TryGetValue(string name, out object value)
            => _dataSet.TryGetValue(name, out value);
        void IDisposable.Dispose() { }
    }
}

