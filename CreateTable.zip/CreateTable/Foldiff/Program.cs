﻿using Binean.Command;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace Binean {
    internal sealed class Program {
        static void Main() {
            var debug = Environment.GetEnvironmentVariable("CMD_DEBUG")?.ToUpper();
            //if (debug == "Y")System.Diagnostics.Debugger.Launch();

            var args = Host.Arguments;
            args.ClearUsage();
            RegisterArgs(args);
            args.Read(Environment.GetCommandLineArgs());

            Process(args);
        }

        private static void Process(Arguments args) {
            var check = args.GetArg("checkFolder", true).CastAs<string>();
            var source = args.GetArg("sourceFolder", true).CastAs<string>();
            var output = args.GetArg("outputFolder", true).CastAs<string>();
            var filters = args.GetArg("f", true).CastAs<string>();
            var prompt = args.GetArg("p", false).CastAs<bool>();
            var remark = args.GetArg("r", true).CastAs<string>();
            var autoDel = args.GetArg("d", false).CastAs<bool>();
            var trim = args.GetArg("t", false).CastAs<bool>();

            //var diff = new Func<string, string, bool>();

            if (!Directory.Exists(check)) {
                Console.Out.WriteLine($"Check folder doesn't exist: {check}");
                return;
            }
            if (!Directory.Exists(source)) {
                Console.Out.WriteLine($"Source folder doesn't exist: {source}");
                return;
            }
            if (string.IsNullOrEmpty(output)) {
                Console.Out.WriteLine($"Missing output {output}");
                return;
            }
            if (string.IsNullOrEmpty(Directory.GetDirectoryRoot(output))) {
                Console.Out.WriteLine($"Invalid output {output}");
                return;
            }
            if (Directory.Exists(output)) {
                if (autoDel) Directory.Delete(output, true);
                else {
                    Console.Out.WriteLine($"Output folder existed! {output}");
                    return;
                }
            }

            Console.Out.WriteLine($"\"Check diff of {check} compare width {source}\"");
            var skip = string.IsNullOrWhiteSpace(remark) ? new Func<string, bool>(l => true)
                : l => l.StartsWith(remark);
            Process(check, source, output, output, filters, trim, prompt, skip);
        }
        private static void Process(string check, string source, string baseOutput, string output, string filters, bool trim, bool prompt, Func<string, bool> skip) {
            if (!Directory.Exists(output)) Directory.CreateDirectory(output);
            foreach (var item in Directory.GetDirectories(check)) {
                var name = Path.GetFileName(item);
                Process(Path.Combine(check, name), Path.Combine(source, name), baseOutput, Path.Combine(output, name), filters, trim, prompt, skip);
            }
            var fils = filters.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);

            var length = fils.Length;
            for (int i = 0; i < length; i++) {
                foreach (var file in Directory.GetFiles(check, fils[i], SearchOption.TopDirectoryOnly)) {
                    var cname = Path.GetFileName(file);
                    var sname = Path.Combine(source, cname);
                    var oFile = Path.Combine(output, cname);
                    var fin = new FileInfo(oFile);
                    var isDiff = !File.Exists(sname) || Diff(file, sname, trim, skip);
                    if (isDiff) File.Copy(file, oFile);
                    if (prompt && fin.Exists) {
                        Console.Out.Write(",");
                        var p = GetRelative(baseOutput, oFile);
                        Console.Write($"\"{Path.GetDirectoryName(p)}\"");
                        Console.Out.Write(",");
                        Console.Write($"\"{Path.GetFileName(p)}\"");
                        Console.Out.Write(",");
                        Console.WriteLine($"\"{Path.GetFileNameWithoutExtension(p)}\"");
                    }
                }
            }
            var folder = new DirectoryInfo(output);
            if (folder.Exists && folder.GetFileSystemInfos().Length == 0) Directory.Delete(output);
        }

        private static bool Diff(string check, string source, bool trim, Func<string, bool> skip) {
            List<string> srce;
            using (var reader = File.OpenText(source))
                srce = ReadAll(reader, trim);

            var cindex = -1;
            int changed = 0;
            int add = 0;
            bool isSkip = true;
            string line;
            using (var reader = File.OpenText(check)) {
                while ((line = reader.ReadLine()) != null) {
                    if (trim) line = line.Trim();
                    cindex++;
                    var index = IndexOf(line, srce);
                    if (index < 0) {
                        changed++;
                        add++;
                        isSkip &= skip(line);
                        continue;
                    }
                    for (int i = 0; i <= index; i++) {
                        srce.RemoveAt(0);
                    }
                    if (index > 0) {
                        changed -= index;
                        continue;
                    }
                    if (changed != 0 && (add == 0 || !isSkip)) {
                        return true;
                    } else {
                        add = 0;
                        changed = 0;
                        isSkip = true;
                    }
                }
                return false;
            }
        }
        private static List<string> ReadAll(TextReader reader, bool trimEnd) {
            List<string> retVal = new List<string>();
            string line;
            while ((line = reader.ReadLine()) != null) {
                retVal.Add(trimEnd ? line.TrimEnd() : line);
            }
            return retVal;
        }
        private static int IndexOf(string line, List<string> source) {
            var length = source.Count;
            for (int i = 0; i < length; i++) {
                if (source[i] == line) return i;
            }
            return -1;
        }

        private static string GetRelative(string basePath, string path) {
            return "\\" + path.Replace(basePath, "").TrimStart('\\');
        }

        private static void RegisterArgs(Arguments args) {
            args.Register("checkFolder", "Check folder")
                .Register("sourceFolder", "Source folder")
                .Register("outputFolder", "Output folder")
                .RegisterOptions("f", "File filters separate with ;", null, "*.cbl;*.cpy;*.ccp;")
                .RegisterOptions("r", "Ignore remark (work unit)", "text", false)
                .RegisterOptions("t", "Trim end", null, false)
                .RegisterOptions("d", "Auto delete output folder", null, false)
                .RegisterOptions("p", "Print result", null, true);
        }
    }
}
