﻿using Binean.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rmdup {
    internal class Program {
        static void Main() {
            var debug = Environment.GetEnvironmentVariable("CMD_DEBUG")?.ToUpper();
            if (debug == "Y") System.Diagnostics.Debugger.Launch();

            var args = Host.Arguments;
            args.ClearUsage();
            RegisterArgs(args);
            args.Read(Environment.GetCommandLineArgs());

            Process(args);
        }
        private static void Process(Arguments args) {
            var input = args.GetArg("input", true).ToString();
            var output = args.GetArg("output")?.ToString();
            var replace = args.GetArg("r").CastAs(() => false);

            if (string.IsNullOrWhiteSpace(input) || !File.Exists(input)) return;

            var list = new Collection<string>();
            using (var reader = File.OpenText(input)) {
                string line;
                while ((line = reader.ReadLine()) != null) {
                    line = line.Trim();
                    if (string.IsNullOrEmpty(line)) continue;
                    if (!list.BinarySearch(i => string.Compare(i, line, false), out int index)) {
                        list.Insert(~index, line);
                    }
                }
            }

            if (string.IsNullOrWhiteSpace(output) && replace) output = input;
            if (!string.IsNullOrWhiteSpace(output)) {
                using (var writer = File.CreateText(output)) {
                    Output(list, writer);
                }
            } else Output(list, Console.Out);
        }
        private static void Output(Collection<string> list, TextWriter writer) {
            var length = list.Count;
            for (int i = 0; i < length; i++) {
                writer.WriteLine(list[i]);
            }
        }

        private static void RegisterArgs(Arguments args) {
            args.Register("input")
                .RegisterOptions("r", "Replace input file")
                .RegisterOptions("output")
            ;
        }
    }
}
