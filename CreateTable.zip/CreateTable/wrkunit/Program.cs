﻿using Binean.Command;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Binean {
    internal sealed class Program {
        static void Main() {
            var debug = Environment.GetEnvironmentVariable("CMD_DEBUG")?.ToUpper();
            //if (debug == "Y")System.Diagnostics.Debugger.Launch();

            var args = Host.Arguments;
            RegisterArgs(args);
            args.Read(Environment.GetCommandLineArgs());

            Process(args);
        }

        private static void Process(Arguments args) {
            var input = args.GetArg("inputFolder", true).CastAs<string>();
            var output = args.GetArg("outputFolder", true).CastAs<string>();
            var wu = args.GetArg("workUnit", true).CastAs<string>();
            var filters = args.GetArg("f", true).CastAs<string>();
            var silent = args.GetArg("s", false).CastAs<bool>();

            if (!Directory.Exists(input)) {
                Console.Out.WriteLine($"Input folder doesn't exist {input}");
                return;
            }
            if (string.IsNullOrEmpty(output)) {
                Console.Out.WriteLine($"Missing output {output}");
                return;
            }
            if (string.IsNullOrEmpty(Directory.GetDirectoryRoot(output))) {
                Console.Out.WriteLine($"Invalid output {output}");
                return;
            }
            if (string.IsNullOrEmpty(wu)) {
                Console.Out.WriteLine("Missing Work unit");
                return;
            }

            Process(input, output, output, wu, filters, silent);
        }
        private static void Process(string input, string baseOutput, string output, string wu, string filters, bool silent) {
            if (!Directory.Exists(output)) Directory.CreateDirectory(output);
            foreach (var item in Directory.GetDirectories(input)) {
                var name = Path.GetFileName(item);
                Process(Path.Combine(input, name), baseOutput, Path.Combine(output, name), wu, filters, silent);
            }
            var fils = filters.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);

            var length = fils.Length;
            for (int i = 0; i < length; i++) {
                foreach (var file in Directory.GetFiles(input, fils[i], SearchOption.TopDirectoryOnly)) {
                    var name = Path.GetFileName(file);
                    var oFile = Path.Combine(output, name);
                    using (var reader = File.OpenText(file)) {
                        using (var writer = File.CreateText(oFile)) {
                            string line;
                            while ((line = reader.ReadLine()) != null) {
                                if (line.StartsWith(wu)) writer.WriteLine(line);
                            }
                        }
                    }
                    var fin = new FileInfo(oFile);
                    if (fin.Exists && fin.Length == 0) {
                        File.Delete(oFile);
                        continue;
                    }
                    if (!silent && fin.Exists) Console.Out.WriteLine(GetRelative(baseOutput, oFile));
                }
            }
        }
        private static string GetRelative(string basePath, string path) {
            return "/" + path.Replace(basePath, "").TrimStart('/');
        }

        private static void RegisterArgs(Arguments args) {
            args.Register("inputFolder", "Input folder")
                .Register("outputFolder", "Output folder")
                .Register("workUnit", "Work Unit")
                .RegisterOptions("f", "File filters separate with ;", null, "*.cbl;*.cpy;*.ccp;")
                .RegisterOptions("s", "Work silent", null, false);
        }
    }
}

