﻿using Binean.Command;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Binean {
    internal sealed class Program {
        static void Main() {
            var debug = Environment.GetEnvironmentVariable("CMD_DEBUG")?.ToUpper();
            //if (debug == "Y")System.Diagnostics.Debugger.Launch();

            RegisterMethods();

            var args = Host.Arguments;
            RegisterArgs(args);
            args.Read(Environment.GetCommandLineArgs());

            Process(args);
        }

        private static void Process(Arguments args) {
            var template = args.GetArg("template", true).ToTemplate();

            args.GetOuptutArgs(out object oFile, out bool oSplit, out bool oAppend);
            using (var reader = args.GetInput(true) ?? Host.Empty) {
                if (oFile == null) {
                    using (var writer = Console.Out) {
                        template.WriteAll(writer, reader);
                    }
                } else if (!oSplit) {
                    using (var writer = File.CreateText(oFile.GetValue(reader).CastAs<string>())) {
                        template.WriteAll(writer, reader);
                    }
                } else {
                    while (reader.MoveNext()) {
                        var name = oFile.GetValue(reader).CastAs<string>();
                        var folder = Path.GetDirectoryName(name);
                        if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);
                        using (var writer = oAppend ? File.AppendText(name) : File.CreateText(name)) {
                            template.Write(writer, reader);
                        }
                    }
                }
            }
        }

        private static void RegisterMethods() {
        }
        private static void RegisterArgs(Arguments args) {
            args.Register("template", "template", ":pattern")
                .RegisterOutputArgs(true)
                .RegisterInputArgs(true)
            ;
        }
        private static void WriteSplit(Template template, IDataSet dataSet, object oFile) {

        }
    }
}

