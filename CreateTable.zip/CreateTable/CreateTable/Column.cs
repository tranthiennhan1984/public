﻿namespace CreateTable {
    internal class Column {
        public string Name { get; set; }
        public string Typename { get; set; }
        public int Length { get; set; }
        public int Scale { get; set; }
        public bool Nulls { get; set; }
        public bool Identity { get; set; }
        public string Default { get; set; }
        public int Start { get; set; }
        public int Increment { get; set; }
        public bool Cycle { get; set; }
        public int Cache { get; set; }
        public int Codepage { get; set; }
        public string Keyseq { get; set; }
        public bool Order { get; set; }
        public int Colno { get; set; }
    }

    internal class Index {
        public string Schema { get; set; }
        public string Name { get; set; }
        public string OwnerType { get; set; }
        public string Columns { get; set; }
        public string UniqueRule { get; set; }
        public string MadeUnique { get; set; }
        public int PCTFREE { get; set; }
        public string Indextype { get; set; }
        public int ColCount { get; set; }
    }
}
