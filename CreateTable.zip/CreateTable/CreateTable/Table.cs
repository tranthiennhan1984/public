﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateTable {
    internal class Table {
        public string Schema { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Status { get; set; }
        public string Tbspace { get; set; }
        public string ITbspace { get; set; }
        public string Codepage { get; set; }

        public List<Column> Columns { get; } = new List<Column>();
        public List<Index> Indexes { get; } = new List<Index>();
    }
}
