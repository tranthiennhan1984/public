﻿using Binean.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace indexof {
    internal class Program {
        static int Main() {
            var debug = Environment.GetEnvironmentVariable("CMD_DEBUG")?.ToUpper();
            if (debug == "Y") System.Diagnostics.Debugger.Launch();

            var args = Host.Arguments;
            RegisterArgs(args);
            args.Read(Environment.GetCommandLineArgs());

            return Process(args);
        }
        private static int Process(Arguments args) {
            var searchString = args.GetArg("searchString", true).ToString();
            var text = args.GetArg("text")?.ToString();
            var ignoreCase = args.GetArg("i").CastAs<bool>();

            var index = -1;
            if (!string.IsNullOrEmpty(text) && !string.IsNullOrEmpty(searchString)) {
                if(ignoreCase) index = text.IndexOf(searchString, StringComparison.OrdinalIgnoreCase);
                else index = text.IndexOf(searchString);
                if (index > 0) {
                    if (args.GetArg("b").CastAs<bool>()) {
                        if (index != 0) index = -1;
                    }
                    if (args.GetArg("e").CastAs<bool>()) {
                        if (index != text.Length - searchString.Length) index = -1;
                    }
                }
            }
            if (index > -1) {
                Console.Out.WriteLine(text);
                return index + 1;
            }
            return 0;
        }
        private static void RegisterArgs(Arguments args) {
            args.Register("searchString")
                .Register("text")
                .RegisterOptions("i", "ignore case")
                .RegisterOptions("b", "At begin")
                .RegisterOptions("e", "At end")
            ;
        }
    }
}
