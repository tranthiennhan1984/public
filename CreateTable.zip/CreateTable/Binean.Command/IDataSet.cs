﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Xml.Linq;

namespace Binean.Command {
    public interface IDataSet : IDisposable {
        bool TryGetValue(string name, out object value);
        int RowId { get; }
        int RowNumber { get; }
        int GroupId { get; set; }
        bool MoveNext();
    }

    //public sealed class DataSet : Dictionary<string, object>, IDataSet {
    //    public int RowId => 0;
    //    public bool MoveNext() => false;
    //    void IDisposable.Dispose() {}
    //}
    public sealed class EnvDataSet : IDataSet {
        public int RowId { get; private set; }
        public int RowNumber => RowId;
        public int GroupId {
            get { return _groupId > 0 ? _groupId : RowId == 0 ? 0 : 1; }
            set { _groupId = value; }
        }
        private int _groupId;
        public bool MoveNext() {
            if (RowId == 0) {
                RowId = 1;
                return true;
            }
            RowId = -1;
            return false;
        }
        public bool TryGetValue(string name, out object value) {
            if (!string.IsNullOrEmpty(name)) {
                value = Environment.GetEnvironmentVariable(name);
                return value != null;
            }
            value = null;
            return false;
        }
        void IDisposable.Dispose() { }
    }
    public sealed class DependSet : IDataSet {
        readonly Dictionary<string, object> _dic = new Dictionary<string, object>(IgnoreCaseComparer.Instance);
        public DependSet(IDataSet parent) {
            Parent = parent;
        }

        public object this[string key] {
            get => _dic[key];
            set => _dic[key] = value;
        }
        public IDataSet Parent { get; }
        public int RowId => Parent?.RowId ?? 1;
        public int RowNumber => Parent?.RowNumber ?? 1;
        public int GroupId {
            get { return _groupId > 0 ? _groupId : RowId == 0 ? 0 : 1; }
            set { _groupId = value; }
        }
        private int _groupId;
        public bool MoveNext() => Parent?.MoveNext() ?? false;
        public bool TryGetValue(string name, out object value) {
            if (_dic.TryGetValue(name, out value)) return true;
            if (Parent == null) return false;
            return Parent.TryGetValue(name, out value);
        }
        void IDisposable.Dispose() {
            Parent?.Dispose();
        }
    }

    //public sealed class Disposable : IDisposable {
    //    Action _disposedAction;
    //    public Disposable(Action disposeAction = null) {
    //        _disposedAction = disposeAction;
    //    }
    //    public void Dispose() {
    //        if (_disposedAction != null) {
    //            _disposedAction.Invoke();
    //            _disposedAction = null;
    //        }
    //    }
    //}
}