﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

namespace Binean.Command {
    public class CsvWriter : IDisposable {
        readonly TextWriter _writer;
        private readonly List<ICsvColumn> _columns = new List<ICsvColumn>();
        Action _disposedAction;

        //public CsvWriter(TextWriter writer) {
        //    _writer = writer;
        //}
        //public CsvWriter(TextWriter writer, params ICsvColumn[] columns) {
        //    _writer = writer;
        //    _columns.AddRange(columns);
        //    HasHeader = CheckHeaders();
        //}
        public CsvWriter(TextWriter writer, IEnumerable<ICsvColumn> columns, bool leaveOpen = false) {
            _writer = writer;
            if (!leaveOpen) _disposedAction = () => {
                if (_writer != null) {
                    _writer.Flush();
                    _writer.Close();
                    _writer.Dispose();
                }
            };
            _columns.AddRange(columns);
            HasHeader = CheckHeaders();
        }
        public void Dispose() {
            if (_disposedAction != null) {
                _disposedAction();
                _disposedAction = null;
            }
        }


        public IReadOnlyList<ICsvColumn> Columns => _columns;
        public bool HasHeader { get; private set; }
        public CsvWriter WriteAll(IDataSet dataSet, bool writeHeader = false, bool isReady = false) {
            if (writeHeader) WriteHeader();
            if (isReady) Write(dataSet);
            while (dataSet.MoveNext()) {
                Write(dataSet);
            }
            return this;
        }
        public CsvWriter WriteHeader() {
            var length = _columns.Count;
            for (int i = 0; i < length; i++) {
                var column = _columns[i];
                var header = column.Header;
                if (string.IsNullOrWhiteSpace(header)) header = $"Col{i + 1}";
                if (i > 0) _writer.Write(',');
                _writer.Write(CsvEscape(header));
            }
            _writer.WriteLine();
            return this;
        }
        public CsvWriter Write(IDataSet dataSet) {
            var length = _columns.Count;
            for (int i = 0; i < length; i++) {
                var column = _columns[i];
                if (i > 0) _writer.Write(',');
                _writer.Write(CsvEscape(column.GetValue(dataSet).CastAs<string>()));
            }
            _writer.WriteLine();
            return this;
        }
        //public CsvWriter WriteLine(){
        //    _writer.WriteLine();
        //    return this;
        //}

        private bool CheckHeaders() {
            var length = _columns.Count;
            for (int i = 0; i < length; i++) {
                var col = _columns[i];
                if (string.IsNullOrWhiteSpace(col.Header)) return false;
            }
            return true;
        }
        private static string CsvEscape(string value) {
            if (string.IsNullOrWhiteSpace(value)) return value;
            var sb = new StringBuilder();
            var length = value.Length;
            var needEsc = false;
            for (int i = 0; i < length; i++) {
                var chr = value[i];
                if (chr == '"') {
                    needEsc = true;
                    sb.Append(chr).Append(chr);
                    continue;
                }
                if (",\r\n\t()".IndexOf(chr) > -1) needEsc = true;
                sb.Append(chr);
            }
            if (needEsc) sb.Append('"').Insert(0, '"');
            return sb.ToString();
        }

    }
    public interface ICsvColumn {
        string Header { get; }
        object GetValue(IDataSet dataSet);
    }
    public sealed class CsvColumn : ICsvColumn {
        public CsvColumn(string header) {
            Header = header;
        }
        public string Header { get; }
        public object GetValue(IDataSet dataSet) {
            if (dataSet.TryGetValue(Header, out object value)) return value;
            return null;
        }
    }
    public sealed class CsvPatternColumn : ICsvColumn {
        public CsvPatternColumn(string header) {
            Header = header;
        }
        public string Header { get; }
        public Template Pattern { get; set; }
        public object GetValue(IDataSet dataSet) {
            if (Pattern == null || !Pattern.TryGetValue(dataSet, out object value)) return null;
            return value;
        }
    }
}

