﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Binean.Command {
    public sealed class Arguments : IDataSet {
        readonly Dictionary<string, Argument> _args = new Dictionary<string, Argument>(IgnoreCaseComparer.Instance);
        readonly List<Argument> _requiredArgs = new List<Argument>();
        readonly object _lock = new object();

        readonly List<UsageItem> _usages = new List<UsageItem>(new UsageItem[] {
                new UsageItem() {
                    Name="pattern",
                    Description="String template"},
                new UsageItem() {
                    Name="colpattern",
                    Description="Column pattern [header]|[pattern]"
                }
            });

        int _maxUsage = 0;
        public int RowId { get; private set; }
        public int RowNumber => RowId;
        public int GroupId {
            get { return _groupId > 0 ? _groupId : RowId == 0 ? 0 : 1; }
            set { _groupId = value; }
        }
        private int _groupId;
        internal Arguments() { }

        void IDisposable.Dispose() {
            RowId = 0;
        }
        private Arguments Register(Argument arg) {
            var name = arg.Name;
            if (string.IsNullOrEmpty(name)) throw new ArgumentNullException("Name");
            if (name.Length > 20) throw new ArgumentException($"{name}'s length is over 20.");

            var nLength = name.Length;
            if (!string.IsNullOrWhiteSpace(arg.Usage)) nLength += arg.Usage.Length;
            if (nLength > _maxUsage) _maxUsage = nLength;

            lock (_lock) {
                if (_args.ContainsKey(name)) throw new ArgumentException($"{name} already registered.");
                _args[arg.Name] = arg;
                if (arg.Required) _requiredArgs.Add(arg);
            }
            return this;
        }
        public Arguments Register(string name, string description = null, string usage = null) {
            Register(new Argument {
                Name = name,
                Required = true,
                Description = description,
                Usage = usage
            });
            return this;
        }
        public Arguments RegisterOptions(string name, string description = null, string usage = null, object defaultValue = null, bool multiple = false) {
            Register(new Argument {
                Name = name,
                Usage = usage,
                Multiple = multiple,
                Description = description,
                DefaultValue = defaultValue
            }); ;
            return this;
        }

        public void AddUsage(UsageItem item) {
            lock (_lock) {
                _usages.Add(item);
            }
        }
        public void ClearUsage() {
            lock (_lock) {
                _usages.Clear();
            }
        }

        public bool TryGetValue(string name, out object value) {
            lock (_lock) {
                if (_args.TryGetValue(name, out Argument arg)) {
                    if (arg.HasInput) {
                        value = arg.Value;
                        return true;
                    }
                    if (arg.DefaultValue != null) {
                        value = arg.DefaultValue;
                        return true;
                    }
                }
            }
            value = null;
            return false;
        }
        public bool MoveNext() {
            if (RowId == 0) {
                RowId = 1;
                return true;
            }
            RowId = -1;
            return false;
        }

        public void Read(string[] args) {
            //var args = Environment.GetCommandLineArgs();
            var length = args.Length;

            if (length == 1 && _requiredArgs.Count > 0) Usage(Console.Out);
            else if (length == 2 && args[1] == "?") Usage(Console.Out);

            for (int i = 1; i < length; i++) {
                var arg = args[i];
                if (string.IsNullOrWhiteSpace(arg)) continue;
                if ("-+".IndexOf(arg[0]) > -1) {
                    var eI = arg.IndexOf(':');
                    if (eI < 0) SetArg(arg.Substring(1), true);
                    else if (eI > 1) SetArg(arg.Substring(1, eI - 1), arg.Substring(eI + 1));
                    else {
                        Console.WriteLine();
                        Console.WriteLine($"Unknown argument: {arg}");
                        Environment.Exit(0);
                    }
                } else SetArg(arg);
            }

            length = _requiredArgs.Count;
            for (int i = 0; i < length; i++) {
                var arg = _requiredArgs[i];
                if (!arg.HasInput) {
                    Console.WriteLine();
                    Console.WriteLine($"Missing required argument: {arg.Name}");
                    Usage(Console.Out);
                }
            }
        }

        private void Usage(TextWriter writer, bool exit = true) {
            writer.WriteLine();
            OnUsage(writer);
            writer.WriteLine();
            if (exit) Environment.Exit(0);
        }
        private void OnUsage(TextWriter writer) {
            var sb = new StringBuilder();

            var name = Path.GetFileNameWithoutExtension(Environment.GetCommandLineArgs()[0]);
            var usageLength = Math.Max(15, _maxUsage + 2);
            sb.Append(" Usage: ").Append(name);

            lock (_lock) {
                var length = _requiredArgs.Count;
                for (int i = 0; i < length; i++) {
                    var arg = _requiredArgs[i];
                    sb.Append(" <").Append(arg.Name).Append('>');
                }
                if (_args.Count > _requiredArgs.Count) {
                    sb.Append(" [option]*");
                }
                writer.WriteLine("-".PadRight(sb.Length + 4, '-'));
                writer.WriteLine(sb.ToString());
                writer.Write(" ");
                writer.WriteLine("-".PadRight(sb.Length + 3, '-'));
                //writer.WriteLine("-".PadRight(sb.Length + 4, '-'));

                for (int i = 0; i < length; i++) {
                    var arg = _requiredArgs[i];
                    writer.Write(arg.Name.PadLeft(usageLength));
                    writer.Write(": ");
                    var desp = arg.Description;
                    if (string.IsNullOrWhiteSpace(desp)) writer.WriteLine();
                    else WriteDescription(writer, new StringReader(desp), usageLength + 2, arg.DefaultValue);
                }
                writer.WriteLine();
                foreach (var key in _args.Keys) {
                    var arg = _args[key];
                    if (arg.Required) continue;
                    var a = arg.Usage;
                    if (!string.IsNullOrWhiteSpace(a)) a = ":" + a;
                    writer.Write($"{(arg.Multiple ? '+' : '-')}{arg.Name}{a}".PadLeft(usageLength));
                    writer.Write(": ");
                    var desp = arg.Description;
                    if (string.IsNullOrWhiteSpace(desp)) writer.WriteLine();
                    else WriteDescription(writer, new StringReader(desp), usageLength + 2, arg.DefaultValue);
                }

                length = _usages.Count;
                if (length == 0) return;
                writer.WriteLine("-".PadRight(sb.Length + 4, '-'));
                writer.WriteLine(" Option type's details");
                writer.Write(" ");
                writer.WriteLine("-".PadRight(sb.Length + 3, '-'));
                for (int i = 0; i < length; i++) {
                    var us = _usages[i];
                    writer.Write(us.Name.PadLeft(usageLength));
                    writer.Write(": ");
                    var desp = us.Description;
                    if (string.IsNullOrWhiteSpace(desp)) writer.WriteLine();
                    else WriteDescription(writer, new StringReader(desp), usageLength + 2, null);
                }
            }
        }
        private void WriteDescription(TextWriter writer, TextReader reader, int position, object defaultValue) {
            string text;
            int line = 0;
            while ((text = reader.ReadLine()) != null) {
                if (++line > 1) {
                    writer.Write(" ".PadRight(position));
                }
                writer.WriteLine(text);
            }
            if (defaultValue != null) {
                if (++line == 1) writer.WriteLine();
                writer.Write(" ".PadRight(position));
                writer.Write("Default: ");
                writer.WriteLine(defaultValue.ToText());
            }
        }

        private void SetArg(object value) {
            var length = _requiredArgs.Count;
            lock (_lock) {
                for (int i = 0; i < length; i++) {
                    var arg = _requiredArgs[i];
                    if (arg.HasInput) continue;
                    arg.Value = value;
                    arg.HasInput = true;
                    return;
                }
            }
            throw new ArgumentException($"All required arguments was inputed, invalid value:{value}");
        }
        private void SetArg(string name, object value) {
            if (string.IsNullOrEmpty(name)) throw new ArgumentNullException("Argument name");
            lock (_lock) {
                if (!_args.TryGetValue(name, out Argument arg)) throw new ArgumentException($"Not support argurment: {name}");
                if (arg.HasInput && !arg.Multiple) throw new ArgumentException($"Argument already inputed:{name}");
                arg.HasInput = true;
                if (arg.Multiple) {
                    if (!(arg.Value is List<object> values)) {
                        values = new List<object>();
                        if (arg.Value != null) values.Add(arg.Value);
                        arg.Value = values;
                    }
                    values.Add(value);
                } else arg.Value = value;
            }
        }
        sealed class Argument {
            internal string Name { get; set; }
            internal bool Required { get; set; }
            internal string Usage { get; set; }
            internal bool Multiple { get; set; }
            internal string Description { get; set; }
            internal object DefaultValue { get; set; }
            internal bool HasInput { get; set; }
            internal object Value { get; set; }
        }

        public sealed class UsageItem {
            public string Name { get; set; }
            public string Description { get; set; }
        }
    }
    sealed class IgnoreCaseComparer : StringComparer {
        public static IgnoreCaseComparer Instance = new IgnoreCaseComparer();
        public override int Compare(string x, string y) {
            if (x == null && y == null) return 0;
            if (x == null) return -1;
            if (y == null) return 1;
            return string.Compare(x, y, true);
        }
        public override bool Equals(string x, string y)
            => Compare(x, y) == 0;
        public override int GetHashCode(string obj) => obj.ToLower().GetHashCode();
    }
}
