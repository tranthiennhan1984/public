﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices.ComTypes;
using System.Text;

namespace Binean.Command {
    public sealed class Template : IEntry {
        readonly List<IEntry> _entries = new List<IEntry>();

        public Template(string pattern) {
            using (var reader = new StringReader(pattern)) {
                Parse(reader);
            }
        }
        public Template(TextReader reader) {
            Parse(reader);
        }

        internal Template() { }
        internal Template(params IEntry[] entries) {
            _entries.AddRange(entries);
        }
        public void Parse(TextReader reader)
            => Parse(reader, null);
        public void Parse(TextReader reader, string ends = "\0") {
            if (ends == null) ends = "\0]";
            else ends += "\0]";
            char chr = reader.PeekChar();
            if (chr == ']') throw new InvalidDataException($"Unexpected {chr}");

            while ((chr = reader.PeekChar()) != CsvReader.Eof) {
                IEntry entry;
                if (ends.IndexOf(chr) > -1) return;
                switch (chr) {
                    case '@':
                        entry = new VarEntry();
                        break;
                    case '&':
                        entry = new MethodEntry();
                        break;
                    case '$':
                        entry = new EnvEntry();
                        break;
                    case '[':
                        entry = reader.ReadTemplateBlock();
                        break;
                    case ']':
                        throw new InvalidDataException($"Unexpected {chr}");
                    default:
                        entry = new TextEntry();
                        break;
                }
                entry.Parse(reader, ends);
                _entries.Add(entry);
            }
        }
        public void WriteAll(TextWriter writer, IDataSet dataSet) {
            while (dataSet.MoveNext()) {
                Write(writer, dataSet);
            }
        }
        public void Write(TextWriter writer, IDataSet dataSet) {
            var length = _entries.Count;
            for (int i = 0; i < length; i++) {
                var entry = _entries[i];
                writer.Write(entry.GetValue(dataSet).CastAs<string>());
            }
        }
        public bool TryGetValue(IDataSet dataSet, out object value) {
            if (_entries.Count == 0) {
                value = null;
                return false;
            }
            if (_entries.Count == 1) return _entries[0].TryGetValue(dataSet, out value);

            value = Read(dataSet);
            return true;
        }
        public string Read(IDataSet dataSet) {
            var sb = new StringBuilder();
            using (var writer = new StringWriter(sb)) {
                Write(writer, dataSet);
            }
            return sb.ToString();
        }
    }
}
