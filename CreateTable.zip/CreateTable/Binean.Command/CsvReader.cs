﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.NetworkInformation;
using System.Runtime.Remoting.Messaging;
using System.Text;

namespace Binean.Command {
    public sealed class CsvReader : IDataSet, IDisposable {
        public const char Eof = '\0';
        readonly TextReader _reader;
        Action _disposedAction;

        public CsvReader(TextReader reader, bool hasHeader = false, Action disposedAction = null) {
            _reader = reader;
            _disposedAction = disposedAction;
            if (HasHeader = hasHeader) {
                Names = ReadLine(_reader);
                RowId = 0;
            }
        }
        public CsvReader(TextReader content, TextReader header, Action disposedAction = null) {
            _reader = content;
            _disposedAction = disposedAction;
            if (header != null) Names = ReadLine(header);
        }
        void IDisposable.Dispose() {
            if (_disposedAction != null) {
                _disposedAction.Invoke();
                _disposedAction = null;
            }
        }

        public bool HasHeader { get; }
        public string[] Names { get; }
        public string[] Values { get; private set; }

        public int RowId { get; private set; }
        public int RowNumber {
            get { return _rowNumber > 0 ? _rowNumber : RowId; }
            set { _rowNumber = value; }
        }
        private int _rowNumber;

        public Template Partition { get; set; }
        public Template PartitionStep { get; set; }
        private string _curPart = string.Empty;
        private string _curPartStep = string.Empty;

        public int GroupId {
            get { return _groupId > 0 ? _groupId : RowId == 0 ? 0 : 1; }
            set { _groupId = value; }
        }
        private int _groupId;

        private string[] ReadLine(TextReader reader) {
            if (reader is null) {
                throw new ArgumentNullException(nameof(reader));
            }

            var retVal = new List<string>();
            string txt = null;
            int value;
            while ((value = _reader.Peek()) > 0) {
                var chr = (char)value;
                if (chr == '\r') {
                    _reader.Read();
                    if (_reader.Peek() != '\n') {
                        retVal.Add(txt);
                        break;
                    }
                    continue;
                }
                if (chr == '\n') {
                    retVal.Add(txt);
                    _reader.Read();
                    break;
                }
                if (chr == ',') {
                    _reader.Read();
                    retVal.Add(txt);
                    txt = null;
                    continue;
                }
                txt = ReadString();
            }
            if (value < 0 && (txt != null || retVal.Count > 0)) retVal.Add(txt);
            return retVal.ToArray();
        }
        private string ReadString() {
            var retVal = new StringBuilder();
            int value = _reader.Peek();
            if (value == 0) return null;
            var chr = (char)value;

            var escChar = "\"".IndexOf(chr) < 0 ? ' ' : chr;
            if (escChar != ' ') _reader.Read();

            while ((value = _reader.Peek()) > 0) {
                chr = (char)value;
                if (escChar != ' ') {
                    _reader.Read();
                    if (chr == escChar) {
                        if ((value = _reader.Peek()) > 0 && ((char)value) == escChar) {
                            _reader.Read();
                            retVal.Append(escChar);
                            continue;
                        }
                        break;
                    }
                    retVal.Append(chr);
                    continue;
                }
                if (",\r\n".IndexOf(chr) >= 0) break;
                retVal.Append(chr);
                _reader.Read();
            }
            if (retVal.Length == 0) return escChar != ' ' ? string.Empty : null;
            return retVal.ToString();
        }

        public bool MoveNext() {
            Values = ReadLine(_reader);
            if (Values.Length > 0) {
                RowId++;
                if (Partition != null) {
                    var par = Partition.Read(this).CastAs(() => string.Empty);
                    var step = (PartitionStep?.Read(this)).CastAs(() => string.Empty);
                    if (string.Compare(par, _curPart, true) == 0) {
                        if (PartitionStep == null) RowNumber++;
                        else if (string.Compare(step, _curPartStep, true) != 0) {
                            RowNumber++;
                            _curPartStep = step;
                        }
                    } else {
                        _curPartStep = step;
                        _curPart = par;
                        RowNumber = 1;
                    }
                }
                return true;
            }
            return false;
        }

        public bool TryGetValue(string name, out object value) {
            if (string.IsNullOrEmpty(name) || Values == null) {
                value = null;
                return false;
            }
            var index = -1;
            if (HasHeader) {
                if (Names == null) {
                    value = null;
                    return false;
                }
                var length = Names.Length;
                for (int i = 0; i < length; i++) {
                    if (string.Compare(Names[i].Trim(), name.Trim(), true) == 0) {
                        index = i;
                        break;
                    }
                }
            }

            if (index < 0 && int.TryParse(name, out int intValue)) {
                index = intValue;
            }

            if (index < 0) {
                value = null;
                return false;
            }

            value = Values[index];
            return true;
        }

        public List<ICsvColumn> GetColumns() {
            var length = Names?.Length ?? 0;
            var retVal = new List<ICsvColumn>();
            if (length > 0) {
                for (int i = 0; i < length; i++) {
                    retVal.Add(new CsvColumn(Names[i]));
                }
                return retVal;
            }
            length = Values?.Length ?? 0;
            for (int i = 0; i < length; i++) {
                retVal.Add(new CsvColumn(i.ToString()));
            }
            return retVal;
        }
    }
    public enum CsvFilter {
        None,
        Yes,
        No,
        Empty,
        HasValue
    }
}

