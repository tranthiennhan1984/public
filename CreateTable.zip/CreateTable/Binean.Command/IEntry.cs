﻿using Binean.Command;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Xml.Linq;
using System.Xml.Schema;

namespace Binean.Command {
    internal interface IEntry {
        void Parse(TextReader reader, string ends);
        bool TryGetValue(IDataSet dataSet, out object value);
    }
    internal abstract class BaseEntry : IEntry {
        public string Name { get; protected set; }
        public void Parse(TextReader reader, string ends) {
            var chr = reader.PeekChar();
            if ("@$".IndexOf(chr) < 0) throw new InvalidDataException($"Unexpected {chr}");
            reader.Read();
            Name = reader.ReadNameOrString();
            return;
        }
        public abstract bool TryGetValue(IDataSet dataSet, out object value);
    }
    internal sealed class TextEntry : IEntry {
        const string separators = "@$&[]\0";
        public TextEntry(string text = null) {
            Text = text;
        }
        public string Text { get; private set; }
        public void Parse(TextReader reader, string ends) {
            ends += separators;
            Text = reader.ReadText(ends, null, '\0', '\\', null);
        }
        public bool TryGetValue(IDataSet dataSet, out object value) {
            value = Text;
            return true;
        }
    }
    internal sealed class VarEntry : BaseEntry {
        public override string ToString()
            => $"{nameof(VarEntry)}[{Name}]";
        public override bool TryGetValue(IDataSet dataSet, out object value) {
            if (string.IsNullOrEmpty(Name) || !dataSet.TryGetValue(Name, out value)) {
                value = null;
                return false;
            }
            return true;
        }
    }
    internal sealed class EnvEntry : BaseEntry {
        public override string ToString()
            => $"{nameof(EnvEntry)}[{Name}]";
        public override bool TryGetValue(IDataSet dataSet, out object value)
            => Host.Env.TryGetValue(Name, out value);
    }
    internal sealed class MethodEntry : IEntry {
        string _name;
        readonly List<Template> _args = new List<Template>();
        public void Parse(TextReader reader, string ends) {
            //&dfadf()
            if (reader.PeekChar() != '&') throw new InvalidDataException("& expected");
            reader.Read();

            _name = reader.ReadText("[")?.Trim();
            if (string.IsNullOrEmpty(_name)) throw new InvalidDataException("Expected method name");
            reader.Read();

            char chr = reader.PeekChar();
            if (chr == ']') {
                reader.Read();
                reader.SkipWhiteSpace();
                return;
            }
            Template template = null;
            while ((chr = reader.PeekChar()) != CsvReader.Eof) {
                if (chr == ']') {
                    _args.Add(template);
                    reader.Read();
                    reader.SkipWhiteSpace();
                    return;
                }
                if (chr == ',') {
                    _args.Add(template);
                    template = null;
                    reader.Read();
                    continue;
                }
                if (template != null) throw new InvalidCastException($"Unexpected {chr}");
                if (chr == '[' || chr == '"' || chr == '\'') template = reader.ReadTemplateBlock();
                else {
                    template = new Template();
                    template.Parse(reader, ",]");
                }
            }
            throw new InvalidDataException("] expected");
        }
        public bool TryGetValue(IDataSet dataSet, out object value) {
            if (!Host.TryGetMethod(_name, out IMethod method)) {
                value = null;
                return false;
            }
            var args = new List<object>();
            var length = _args.Count;
            for (int i = 0; i < length; i++) {
                args.Add(_args[i]);
            }
            value = method.GetValue(dataSet, args);
            return true;
        }
    }
}
