﻿using System.CodeDom;
using System.Collections;
using System.Data.Common;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace Binean.Command {
    public interface IMethod {
        string Name { get; }
        object GetValue(IDataSet dataSet, IList args);
        void Usage(TextWriter writer);
    }
    public sealed class UsageMethod : IMethod {
        public string Name => "usage";
        public object GetValue(IDataSet dataSet, IList args) {
            if (args.Count != 1) throw new InvalidDataException("Method name expected");
            var name = args[0].GetValue(dataSet).CastAs<string>();
            if (!Host.TryGetMethod(name, out IMethod method)) throw new InvalidDataException($"Missing method: {name}");
            var sb = new StringBuilder();
            sb.AppendLine();
            using (var writer = new StringWriter(sb)) {
                method.Usage(writer);
            }
            return sb.ToString();
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine(" Usage: Usage(<methodName>)");
        }
    }

    public sealed class RowIdMethod : IMethod {
        public string Name => "rowId";
        public object GetValue(IDataSet dataSet, IList args) {
            if (args.Count > 1) throw new InvalidDataException("Row id expected");
            if (args.Count == 0) return dataSet.RowId;
            var value = dataSet.RowId;
            if (args.Count == 0) return value;

            var rId = args[0].GetValue(dataSet).CastAs<int>();
            if (rId == 0) return value > 1;
            if (rId > 0) return value == rId;
            return (value % (-rId)) == 0;
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine(" Usage: rowid(<id>)");
        }
    }
    public sealed class GroupIdMethod : IMethod {
        public string Name => "groupId";
        public object GetValue(IDataSet dataSet, IList args) {
            if (args.Count > 1) throw new InvalidDataException("Row id expected");
            if (args.Count == 0) return dataSet.GroupId;
            var value = dataSet.GroupId;
            if (args.Count == 0) return value;

            var rId = args[0].GetValue(dataSet).CastAs<int>();
            if (rId == 0) return value > 1;
            if (rId > 0) return value == rId;
            return (value % (-rId)) == 0;
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine(" Usage: rowid(<id>)");
        }
    }
    public sealed class RowNumMethod : IMethod {
        public string Name => "rowNum";
        public object GetValue(IDataSet dataSet, IList args) {
            if (args.Count > 1) throw new InvalidDataException("Row id expected");
            var value = dataSet.RowNumber;
            if (args.Count == 0) return value;

            var rId = args[0].GetValue(dataSet).CastAs<int>();
            if (rId == 0) return value > 1;
            if (rId > 0) return value == rId;
            return (value % (-rId)) == 0;
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine(" Usage: rowid(<id>)");
        }
    }
    public sealed class IfMethod : IMethod {
        public string Name => "if";
        public object GetValue(IDataSet dataSet, IList args) {
            if (args.Count > 3) throw new InvalidDataException("Invalid argument count");
            var cond = args[0].GetValue(dataSet).CastAs<bool>();
            if (cond) return args.Count < 2 ? null : args[1].GetValue(dataSet);
            return args.Count < 3 ? null : args[2].GetValue(dataSet);
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine(" Usage: if(<condition>,[true],[false])");
        }
    }
    public sealed class AndMethod : IMethod {
        public string Name => "and";
        public object GetValue(IDataSet dataSet, IList args) {
            var length = args.Count;
            if (length == 0) return false;
            for (int i = 0; i < length; i++) {
                if (!args[i].GetValue(dataSet).CastAs<bool>()) return false;
            }
            return true;
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine(" Usage: and([cond1],[cond2],..)");
        }
    }
    public sealed class OrMethod : IMethod {
        public string Name => "or";
        public object GetValue(IDataSet dataSet, IList args) {
            var length = args.Count;
            if (length == 0) return true;
            for (int i = 0; i < length; i++) {
                if (args[i].GetValue(dataSet).CastAs<bool>()) return true;
            }
            return false;
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine(" Usage: or([cond1],[cond2],..)");
        }
    }
    public sealed class TemplateMethod : IMethod {
        public string Name => "tmpl";
        public object GetValue(IDataSet dataSet, IList args) {
            if (args.Count != 1) throw new InvalidDataException("Invalid argument count");
            var file = args[0].GetValue(dataSet).CastAs<string>();
            var txt = File.ReadAllText(file);
            var template = new Template(txt);
            return template.GetValue(dataSet);
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine(" Usage: tmplf(<fileName>)");
        }
    }
    public sealed class CompMethod : IMethod {
        public CompMethod(string name) {
            Name = name;
        }
        public string Name { get; set; }
        public object GetValue(IDataSet dataSet, IList args) {
            if (args.Count != 2) throw new InvalidDataException("Invalid argument count");
            var arg1 = args[0].GetValue(dataSet).CastAs<string>();
            var arg2 = args[1].GetValue(dataSet).CastAs<string>();
            int comp;
            if (double.TryParse(arg1, out double a1) && double.TryParse(arg2, out double a2)) comp = a1.CompareTo(a2);
            else comp = string.Compare(arg1, arg2, true);
            switch (Name) {
                case "eq": return comp == 0;
                case "neq": return comp != 0;
                case "gt": return comp > 0;
                case "gte": return comp >= 0;
                case "lt": return comp < 0;
                case "lte": return comp <= 0;
                default: throw new InvalidDataException($"Not supported comp type: {Name}");
            }
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine($" Usage: {Name}(<tmpl1>,<tmpl2>)");
        }
    }
    public sealed class IsNullMethod : IMethod {
        public IsNullMethod(string name) {
            Name = name;
        }
        public string Name { get; set; }
        public object GetValue(IDataSet dataSet, IList args) {
            if (args.Count != 1) throw new InvalidDataException("Invalid argument count");
            var arg1 = args[0].GetValue(dataSet);
            switch (Name) {
                case "isNull": return arg1 == null;
                default: return arg1 != null;
            }
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine($" Usage: {Name}(<tmpl1>)");
        }
    }
    public sealed class IsEmptyMethod : IMethod {
        public IsEmptyMethod(string name) {
            Name = name;
        }
        public string Name { get; set; }
        public object GetValue(IDataSet dataSet, IList args) {
            if (args.Count != 1) throw new InvalidDataException("Invalid argument count");
            var arg1 = args[0].GetValue(dataSet).CastAs<string>();
            switch (Name) {
                case "isEmpty": return string.IsNullOrEmpty(arg1);
                default: return !string.IsNullOrEmpty(arg1);
            }
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine($" Usage: {Name}(<tmpl1>)");
        }
    }
    public sealed class LeftMethod : IMethod {
        public string Name => "left";
        public object GetValue(IDataSet dataSet, IList args) {
            if (args.Count != 2) throw new InvalidDataException("Invalid argument count");
            var str = args[0].GetValue(dataSet).CastAs<string>();
            var count = args[1].GetValue(dataSet).CastAs<int>();
            return str.Substring(0, count);
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine($" Usage: {Name}(<string>,<count>)");
        }
    }
    public sealed class RightMethod : IMethod {
        public string Name => "right";
        public object GetValue(IDataSet dataSet, IList args) {
            if (args.Count != 2) throw new InvalidDataException("Invalid argument count");
            var str = args[0].GetValue(dataSet).CastAs<string>();
            var count = args[1].GetValue(dataSet).CastAs<int>();
            return str.Substring(str.Length - count);
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine($" Usage: {Name}(<string>,<count>)");
        }
    }
    public sealed class SubStrMethod : IMethod {
        public string Name => "subStr";
        public object GetValue(IDataSet dataSet, IList args) {
            if (args.Count < 2 || args.Count > 3) throw new InvalidDataException("Invalid argument count");
            var str = args[0].GetValue(dataSet).CastAs<string>();
            var index = args[1].GetValue(dataSet).CastAs<int>();
            if (args.Count > 2) return str.Substring(index, args[2].GetValue(dataSet).CastAs<int>());
            else return str.Substring(index);
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine($" Usage: {Name}(<string>,<startIndex>,[length])");
        }
    }
    public sealed class TextMethod : IMethod {
        public string Name => "text";
        public object GetValue(IDataSet dataSet, IList args) {
            if (args.Count != 1) throw new InvalidDataException("Invalid argument count");
            var str = args[0].GetValue(dataSet).CastAs<string>();
            if (string.IsNullOrWhiteSpace(str) || !File.Exists(str)) return str;
            return File.ReadAllText(str);
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine($" Usage: {Name}(<filePath>)");
        }
    }
    public sealed class AligmentMethod : IMethod {
        public AligmentMethod(string name) {
            Name = name;
        }
        public string Name { get; }
        public object GetValue(IDataSet dataSet, IList args) {
            if (args.Count != 2) throw new InvalidDataException("Invalid argument count");

            var text = args[0].GetValue(dataSet).CastAs<string>();
            var totalWidth = args[1].GetValue(dataSet).CastAs<int>();
            if (totalWidth <= 0) return text;
            if (text == null) text = string.Empty;

            if (text.Length == totalWidth) return text;
            if (text.Length < totalWidth) {
                switch (Name) {
                    case "afleft":
                    case "aleft": return text.PadRight(totalWidth);

                    case "afright":
                    case "aright": return text.PadLeft(totalWidth);

                    case "afcenter":
                    case "acenter": return text.PadCenter(totalWidth);

                    default: throw new InvalidDataException($"Unknown method name: {Name}");
                }
            }
            switch (Name) {
                case "aright":
                case "aleft":
                case "acenter": return text;

                case "afleft": return text.Substring(0, totalWidth);
                case "afright": return text.Substring(text.Length - totalWidth);
                case "afcenter": return text.Substring((text.Length - totalWidth) / 2, totalWidth);

                default: throw new InvalidDataException($"Unknown method name: {Name}");
            }
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine($" Usage: {Name}(<value>,<totalWidth>)");
        }
    }
    public sealed class Db2TypeMethod : IMethod {
        public string Name => "db2Type";
        public object GetValue(IDataSet dataSet, IList args) {
            if (args.Count != 3) throw new InvalidDataException("Invalid argument count");
            var typeName = args[0].GetValue(dataSet).CastAs<string>();
            var length = args[1].GetValue(dataSet).CastAs<int>();
            var scale = args[2].GetValue(dataSet).CastAs<int>();

            if (typeName == "CHARACTER") typeName = "CHAR";

            if (length > 0 && typeName.IndexOf("CHAR") > -1) {
                return $"{typeName}({length.ToString().PadLeft(2, '0')})";
            }

            if (typeName == "DECIMAL") {
                return $"{typeName}({length.ToString().PadLeft(2, '0')}, {scale.ToString().PadLeft(2, '0')})";
            }
            return typeName;
        }
        public void Usage(TextWriter writer) {
            writer.WriteLine($" Usage: {Name}(<type>,<length>,<scale>)");
        }
    }

    public sealed class Db2OptionMethod : IMethod {
        public string Name => "db2Opt";
        public object GetValue(IDataSet dataSet, IList args) {
            if (args.Count != 2) throw new InvalidDataException("Invalid argument count");
            var nulls = args[0].GetValue(dataSet).CastAs<bool>();
            var defl = args[1].GetValue(dataSet).CastAs<string>();
            var dVal = string.IsNullOrEmpty(defl) ? "" : $" {defl}";

            return !nulls ? defl != null
                ? $"NOT NULL WITH DEFAULT{dVal}" : "NOT NULL" : defl != null ? $"WITH DEFAULT{dVal}" : "";

        }
        public void Usage(TextWriter writer) {
            writer.WriteLine($" Usage: {Name}(<nulls>,<defaults>)");
        }
    }
}
