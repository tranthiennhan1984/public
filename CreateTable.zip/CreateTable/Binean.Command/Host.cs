﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using static System.Net.Mime.MediaTypeNames;
using System.IO;
using System.Xml.Linq;

namespace Binean.Command {
    public static class Host {
        private static readonly IDataSet _empty = new EmptyDataSet();
        public static IDataSet Empty => _empty;

        private static readonly Arguments _arguments = new Arguments().RegisterOptions("?", "Help");
        public static Arguments Arguments => _arguments;

        private static DependSet _env;
        public static DependSet Env => _env;

        static readonly Dictionary<string, IMethod> _methods = new Dictionary<string, IMethod>(IgnoreCaseComparer.Instance);

        static Host() {
            _env = new DependSet(new EnvDataSet());
            new UsageMethod().Register();
            
            new RowIdMethod().Register();
            new GroupIdMethod().Register();
            new RowNumMethod().Register();

            new IfMethod().Register();
            new AndMethod().Register();
            new OrMethod().Register();
            new TemplateMethod().Register();

            new CompMethod("eq").Register();
            new CompMethod("neq").Register();
            new CompMethod("gt").Register();
            new CompMethod("gte").Register();
            new CompMethod("lt").Register();
            new CompMethod("lte").Register();

            new AligmentMethod("aleft").Register();
            new AligmentMethod("aright").Register();
            new AligmentMethod("acenter").Register();
            new AligmentMethod("afleft").Register();
            new AligmentMethod("afright").Register();
            new AligmentMethod("afcenter").Register();

            new IsNullMethod("isNull").Register();
            new IsNullMethod("isNotNull").Register();

            new IsEmptyMethod("isEmpty").Register();
            new IsEmptyMethod("isNotEmpty").Register();

            new SubStrMethod().Register();
            new RightMethod().Register();
            new LeftMethod().Register();

            new TextMethod().Register();
        }

        public static void SetLocal() {
            _env = new DependSet(Env);
        }
        public static void EndLocal() {
            _env = (DependSet)_env.Parent;
        }

        public static bool TryGetMethod(string name, out IMethod method)
            => _methods.TryGetValue(name, out method);
        public static void SetMethod(string name, IMethod method)
            => _methods[name] = method;
        public static void Register(this IMethod method) {
            if (_methods.ContainsKey(method.Name)) throw new InvalidOperationException($"Duplicate Method name: {method.Name}");
            _methods[method.Name] = method;
        }

        class EmptyDataSet : IDataSet {
            public int RowId { get; private set; }
            public int RowNumber => RowId;
            public int GroupId {
                get { return _groupId > 0 ? _groupId : RowId == 0 ? 0 : 1; }
                set { _groupId = value; }
            }
            private int _groupId;
            void IDisposable.Dispose() { RowId = 0; }
            public bool MoveNext() {
                if (RowId == 0) {
                    RowId = 1;
                    return true;
                }
                RowId = -1;
                return false;
            }
            public bool TryGetValue(string name, out object value) {
                value = null;
                return false;
            }
        }
    }
}
