﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net.Http.Headers;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Remoting.Messaging;
using System.Security.Principal;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace Binean.Command {
    public static partial class Extension {
        public static void Assert(bool condition, string message = null, int errorCode = 0) {
            if (condition) return;
            if (!string.IsNullOrEmpty(message)) Console.WriteLine(message);
            Environment.Exit(errorCode);
        }

        public static string ToText(this object obj) => obj.CastAs<string>();
        public static string PadCenter(this string text, int totalWidth, char paddingChar = ' ') {
            if (text.Length >= totalWidth) return text;
            var sb = new StringBuilder(text);
            while (sb.Length < totalWidth) {
                sb.Append(paddingChar);
                if (sb.Length < totalWidth) sb.Insert(0, paddingChar);
            }
            return sb.ToString();
        }

        public static char PeekChar(this TextReader reader) {
            var v = reader.Peek();
            if (v < 0) return CsvReader.Eof;
            return (char)v;
        }

        public static Template ReadTemplateBlock(this TextReader reader) {
            var chr = reader.PeekChar();
            if (chr == '[') {
                reader.Read();
                reader.SkipWhiteSpace();
                var retVal = new Template();
                retVal.Parse(reader, "]");
                chr = reader.PeekChar();
                if (chr != ']') throw new InvalidDataException("] expected");
                reader.Read();
                reader.SkipWhiteSpace();
                return retVal;
            }

            string text;
            if (chr == '"') {
                reader.Read();
                text = ReadText(reader, string.Empty, string.Empty, chr);
            } else if (chr == '\'') {
                reader.Read();
                text = ReadText(reader, string.Empty, string.Empty, chr, '\0');
            } else text = reader.ReadName();
            return new Template(new TextEntry(text));
        }
        public static string ReadNameOrString(this TextReader reader) {
            var chr = reader.PeekChar();
            if (chr == '"') {
                reader.Read();
                return ReadText(reader, string.Empty, string.Empty, chr);
            }
            if (chr == '\'') {
                reader.Read();
                return ReadText(reader, string.Empty, string.Empty, chr, '\0');
            }
            return reader.ReadName();
        }
        public static string ReadName(this TextReader reader) {
            var sb = new StringBuilder();
            char chr;
            while (true) {
                chr = reader.PeekChar();
                if (chr == CsvReader.Eof || !(chr == '_' || char.IsLetterOrDigit(chr))) {
                    return sb.ToString();
                }
                sb.Append(chr);
                reader.Read();
            }
        }
        public static string ReadText(this TextReader reader, string ends, string endNext = null, char eEscape = '\0', char escape = '\\', string error = "\r\n\0") {
            var sb = new StringBuilder();
            if (error == null) error = string.Empty;
            if (ends == null) ends = string.Empty;
            if (endNext == null) endNext = string.Empty;

            char chr;
            while (true) {
                chr = reader.PeekChar();
                if (ends.IndexOf(chr) > -1) {
                    return sb.ToString();
                }
                if (error.IndexOf(chr) > -1) break;
                if (endNext.IndexOf(chr) > -1) {
                    reader.Read();
                    return sb.ToString();
                }

                if (chr == CsvReader.Eof)
                    break;

                if (chr == eEscape) {
                    reader.Read();
                    if (reader.PeekChar() == eEscape) {
                        reader.Read();
                        sb.Append(eEscape);
                        continue;
                    }
                    return sb.ToString();
                }

                if (chr == escape) {
                    reader.Read();
                    chr = reader.PeekChar();
                    if (chr == CsvReader.Eof) throw new InvalidDataException("Unexpected \0");
                    var index = "rnt0".IndexOf(chr);
                    if (index > -1) sb.Append("\r\n\t\0"[index]);
                    else sb.Append(chr);
                    reader.Read();
                    continue;
                }
                sb.Append(chr);
                reader.Read();
            }

            if (eEscape != CsvReader.Eof) throw new InvalidDataException($"expected {eEscape}");
            if (!string.IsNullOrEmpty(ends)) throw new InvalidDataException($"expected {ends}");
            if (!string.IsNullOrEmpty(endNext)) throw new InvalidDataException($"expected {endNext}");
            throw new InvalidDataException($"Unexpected {chr}");
        }
        public static void SkipWhiteSpace(this TextReader reader, string ends = null, string next = "\n") {
            if (ends == null) ends = string.Empty;
            if (next == null) next = string.Empty;
            char chr;
            while ((chr = reader.PeekChar()) != CsvReader.Eof) {
                if (next.IndexOf(chr) > -1) { reader.Read(); return; }
                if (ends.IndexOf(chr) > -1) return;
                if (!char.IsWhiteSpace(chr)) return;
                reader.Read();
            }
        }


        internal static object GetValue(this IEntry entry, IDataSet dataSet) {
            if (!entry.TryGetValue(dataSet, out object value))
                throw new InvalidDataException($"Can not get value of {entry}");
            return value;
        }
        public static object GetValue(this object obj, IDataSet dataSet) {
            if (obj is IEntry ent) return ent.GetValue(dataSet);
            if (obj is Template retVal) return retVal.Read(dataSet);
            if (obj is TextReader reader) return new Template(reader).Read(dataSet);
            if (obj is string txt) return new Template(txt).Read(dataSet);
            return obj;
        }

        public static Template ToTemplate(this object obj) {
            if (obj is Template retVal) return retVal;
            if (obj is string txt) return new Template(txt);
            if (obj is TextReader reader) return new Template(reader);
            return null;
        }

        public static object GetArg(this Arguments args, string name, bool reqired = false) {
            if (args.TryGetValue(name, out object v)) return v;
            if (reqired) throw new ArgumentException($"Missing argument:{name}");
            return null;
        }

        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static string EnsureStringValue(this string args)
        //=> new Template(args).Read(Host.Empty).CastAs<string>();

        public static Arguments RegisterInputArgs(this Arguments args, bool option = false) {
            if (option) args.RegisterOptions("if", "Input file in csv format");
            else args.Register("inputPath", "Input file in csv format");

            return args.RegisterOptions("ic", "Input file include header")
                .RegisterOptions("ih", "Input header", ":pattern")
                .RegisterOptions("ip", "Input partition", ":pattern")
                .RegisterOptions("ips", "Input partition step", ":pattern");
        }
        public static CsvReader GetInput(this Arguments args, bool option = false) {
            var iArg = args.GetArg("inputPath");
            if (iArg == null) iArg = args.GetArg("if");
            if (iArg == null && option) return null;

            var ifile = iArg.GetValue(Host.Empty).CastAs<string>();
            if (string.IsNullOrWhiteSpace(ifile) && option) return null;

            var input = File.OpenText(ifile);

            CsvReader retVal = null;
            if (args.GetArg("ic").CastAs(false)) retVal = new CsvReader(input, true, () => input.Dispose());
            else if (args.GetArg("ih").GetValue(Host.Empty) is string ihp) {
                using (var ihr = new StringReader(ihp)) {
                    retVal = new CsvReader(input, ihr, () => input.Dispose());
                }
            } else retVal = new CsvReader(input, false, () => input.Dispose());

            if (args.GetArg("ip").ToTemplate() is Template ip) {
                retVal.Partition = ip;
                retVal.PartitionStep = args.GetArg("ips").ToTemplate();
            }
            return retVal;
        }
        public static Arguments RegisterOutputArgs(this Arguments args, bool option = false) {
            if (!option) return args.Register("outputPath", "Output file");
            return args.RegisterOptions("of", "Output file", ":pattern")
                .RegisterOptions("os", "Output split")
                .RegisterOptions("oa", "Output appended");
        }
        public static void GetOuptutArgs(this Arguments args, out object oFile, out bool oSplit, out bool oAppend) {
            oFile = args.GetArg("outputPath");
            if (oFile != null) {
                oSplit = false;
                oAppend = false;
                return;
            }

            oFile = args.GetArg("of");
            oSplit = args.GetArg("os").GetValue(Host.Empty).CastAs<bool>();
            oAppend = args.GetArg("oa").GetValue(Host.Empty).CastAs<bool>();
        }

        public static List<ICsvColumn> BuildColumns(this Arguments args, string argName = "col") {
            if (!args.TryGetNotNull(argName, out List<object> cargs)) return null;
            var colums = new List<ICsvColumn>();
            var maps = new Dictionary<string, CsvPatternColumn>(IgnoreCaseComparer.Instance);

            CsvPatternColumn col = null;

            var length = cargs.Count;
            for (int i = 0; i < length; i++) {
                var carg = cargs[i].CastAs<string>();
                if (string.IsNullOrWhiteSpace(carg)) continue;
                var index = carg.IndexOf('|');
                if (index > 0) {
                    var cname = carg.Substring(0, index).Trim();
                    carg = carg.Substring(index + 1);
                    if (!maps.TryGetValue(cname, out col)) {
                        col = new CsvPatternColumn(cname);
                        colums.Add(col);
                        maps[cname] = col;
                    }
                } else {
                    col = new CsvPatternColumn(null);
                    colums.Add(col);
                }

                if (string.IsNullOrEmpty(carg)) continue;
                col.Pattern = carg.ToTemplate();
            }

            return colums.Count == 0 ? null : colums;
        }

        public static bool TryGetNotNull<T>(this Arguments args, string name, out T value) {
            if (args.TryGetValue(name, out object v)) {
                value = v.CastAs<T>();
                return value != null;
            }
            value = default;
            return false;
        }
        public static bool TryGetNotEmpty(this Arguments args, string name, out string value) {
            if (args.TryGetValue(name, out object v)) {
                value = v.CastAs<string>();
                return !string.IsNullOrWhiteSpace(value);
            }
            value = default;
            return false;
        }
        //public static string GetTextArg(this Arguments args, string name, bool required = false) {
        //    if (args.TryGetValue(name, out object v)) {
        //        var value = v.CastAs<string>();
        //        if (required && string.IsNullOrWhiteSpace(value)) throw new ArgumentException($"Missing argument:{name}");
        //        return value.GetValue(Host.Empty).CastAs<string>();
        //    }
        //    if (required) throw new ArgumentException($"Missing argument:{name}");
        //    return null;
        //}
        //public static Template GetPatternArg(this Arguments args, string name, bool required = false) {
        //    var pattern = GetTextArg(args, name, required);
        //    if (pattern == null) return null;
        //    return new Template(pattern);
        //}

        //public static string CsvEscape(this string value) {
        //    if (string.IsNullOrWhiteSpace(value)) return value;
        //    var sb = new StringBuilder();
        //    var length = value.Length;
        //    var needEsc = false;
        //    for (int i = 0; i < length; i++) {
        //        var chr = value[i];
        //        if (chr == '"') {
        //            needEsc = true;
        //            sb.Append(chr).Append(chr);
        //            continue;
        //        }
        //        if (",\r\n\t()".IndexOf(chr) > -1) needEsc = true;
        //        sb.Append(chr);
        //    }
        //    if (needEsc) sb.Append('"').Insert(0, '"');
        //    return sb.ToString();
        //}

        #region :: Converter Helpers ::
        public const string DateTimeFormat = "yyyy-MM-dd-HH.mm.ss";
        public const string DateFormat = "yyyy-MM-dd";
        private static readonly Dictionary<Type, string> _builtInTypeNames
            = new Dictionary<Type, string>() {
                { typeof(bool), "bool" },
                { typeof(byte), "byte" },
                { typeof(char), "char" },
                { typeof(decimal), "decimal" },
                { typeof(double), "double" },
                { typeof(float), "float" },
                { typeof(int), "int" },
                { typeof(long), "long" },
                { typeof(object), "object" },
                { typeof(sbyte), "sbyte" },
                { typeof(short), "short" },
                { typeof(string), "string" },
                { typeof(uint), "uint" },
                { typeof(ulong), "ulong" },
                { typeof(ushort), "ushort" }
            };

        public static string GetTypeDisplayName(this Type type) {
            if (type.IsGenericType) {
                var fullName = type.GetGenericTypeDefinition().FullName;
                if (fullName == null) return null;

                var parts = fullName.Split('+');

                for (var i = 0; i < parts.Length; i++) {
                    var partName = parts[i];

                    var backTickIndex = partName.IndexOf('`');
                    if (backTickIndex >= 0) {
                        partName = partName.Substring(0, backTickIndex);
                    }

                    parts[i] = partName;
                }

                return string.Join(".", parts);
            } else if (_builtInTypeNames.ContainsKey(type)) {
                return _builtInTypeNames[type];
            } else {
                var fullName = type.FullName;
                if (fullName == null) return null;
                if (!type.IsNested) return fullName;
                return fullName.Replace('+', '.');
            }
        }
        public static string GetTypeName(this Type type) {
            var name = type.AssemblyQualifiedName;
            if (name == null) return null;
            var index = name.IndexOf(',', 0);
            index = name.IndexOf(',', index + 1);
            return name.Substring(0, index);
        }
        public static Type ToType(this object value) {
            if (value == null) return null;
            if (value is Type type) return type;
            if (value is string typeName) {
                try {
                    return Type.GetType(typeName);
                } catch (Exception ex) {
                    var _ = ex;
                    return null;
                }
            }
            return null;
        }

        public static string ToTimeString(this DateTime time) => time.ToString(DateTimeFormat, CultureInfo.CurrentCulture);

        private static bool ConvertToDateTime(this string text, out object target) {
            if (string.IsNullOrWhiteSpace(text)) { target = null; return false; }

            if (DateTime.TryParseExact(text, text.Length == 10 ? DateFormat : DateTimeFormat,
                CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime dt)) {
                target = dt; return true;
            }

            target = null;
            return false;
        }

        public static bool ConvertTo(this object value, Type targetType, out object target) {
            if (targetType == null) { target = null; return false; }
            var underlyingType = Nullable.GetUnderlyingType(targetType);

            var canBeNull = underlyingType != null || targetType == typeof(object);

            if (value is DBNull) { target = null; return canBeNull; }

            if (targetType == typeof(object)) { target = value; return true; }

            if (value == null) { target = null; return canBeNull; }

            if (targetType == typeof(Type)) { target = value.ToType(); return target != null; }

            var valueType = value.GetType();
            if (valueType == targetType || targetType.IsAssignableFrom(valueType)) {
                target = value; return true;
            }

            if (targetType.IsEnum) return ConvertToEnum(value, targetType, out target);
            if (underlyingType != null && underlyingType.IsEnum) {
                return ConvertToEnum(value, underlyingType, out target);
            }
            if (targetType == typeof(bool)) {
                if (value is string txt) {
                    txt = txt.ToUpper();
                    if (txt == "Y") {
                        target = true;
                        return true;
                    }
                    if (txt == "N") {
                        target = false;
                        return true;
                    }
                }
            }

            if (value is IConvertible && targetType.IsPrimitive) {
                try {
                    target = Convert.ChangeType(value, targetType, CultureInfo.CurrentCulture);
                    return true;
                } catch {
                    target = null; return false;
                }
            }

            if (targetType == typeof(string)) {
                target = value is Type t ? t.GetTypeName()
                    : value is DateTime dt ? dt.ToTimeString()
                    : value.ToString();
                return true;
            }

            target = null;


            if (targetType == typeof(DateTime) || underlyingType == typeof(DateTime)) {
                return value is string txt && ConvertToDateTime(txt, out target);
            }
            //if (targetType == typeof(byte[])) {
            //    if (value is string txt && txt.TryParseBlob(out byte[] blob)) {
            //        target = blob;
            //        return true;
            //    }
            //    return false;
            //}
            if (targetType == typeof(Guid) || underlyingType == typeof(Guid)) {
                if (value is string txt && Guid.TryParse(txt, out Guid retVal)) {
                    target = retVal; return true;
                }
                return false;
            }
            return false;
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool ConvertTo<T>(this object value, out T target) {
            if (!ConvertTo(value, typeof(T), out object obj)) {
                target = default;
                return false;
            }
            target = (T)obj;
            return true;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool ConvertToEnum<T>(this object value, out T target) {
            object obj = null;
            if (value != null && ConvertToEnum(value, typeof(T), out obj)) {
                target = default;
                return false;
            }
            target = (T)obj;
            return true;
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object CastAs(this object value, Type targetType, Func<object> fallback = null)
            => ConvertTo(value, targetType, out object retVal) ? retVal
            : fallback != null ? fallback() : DefaultValue(targetType);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T CastAs<T>(this object value, T fallback)
            => ConvertTo(value, typeof(T), out object retVal) ? (T)retVal : fallback;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T CastAs<T>(this object value, Func<T> fallback = null)
            => ConvertTo(value, typeof(T), out object retVal) ? (T)retVal
            : fallback != null ? fallback() : default;

        public static object CastAsDbValue(this object value, Type targetType, Func<object> fallback = null) {
            if (value == null) return Nullable.GetUnderlyingType(targetType) == null ? null : DBNull.Value;
            var retVal = CastAs(value, targetType, fallback);
            if (retVal != null) return retVal;
            return Nullable.GetUnderlyingType(targetType) == null ? null : DBNull.Value;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object DefaultValue(this Type type)
            => Nullable.GetUnderlyingType(type) == null && type.IsValueType
            ? Activator.CreateInstance(type) : null;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Default<T>() => (T)DefaultValue(typeof(T));

        internal static bool ConvertToEnum(object value, Type targetType, out object target) {
            if (value is string text) {
                try {
                    target = Enum.Parse(targetType, text, true);
                    return true;
                } catch (Exception ex) {
                    var _ = ex; target = null; return false;
                }
            }

            try {
                target = Enum.ToObject(targetType, value); return true;
            } catch (Exception ex) {
                var _ = ex; target = null; return false;
            }
        }
        public static bool BinarySearch<T>(this IList<T> list, Func<T, int> comparison, out int index, int startIndex = 0, int length = -1) {
            if (list == null) {
                index = ~0;
                return false;
            }

            var low = startIndex;
            var hi = (length < 0 ? list.Count : low + length) - 1;
            if (low < 0 || hi >= list.Count) {
                throw new IndexOutOfRangeException();
            }

            while (low <= hi) {
                var mid = low + ((hi - low) >> 1);
                var comp = comparison(list[mid]);
                if (comp == 0) {
                    index = mid;
                    return true;
                }

                if (comp > 0) {
                    hi = mid - 1;
                } else {
                    low = mid + 1;
                }
            }
            index = ~low;
            return false;
        }
        #endregion
    }
}
