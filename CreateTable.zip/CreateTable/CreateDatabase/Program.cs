﻿using System;
using System.Data.Common;
using System.Formats.Asn1;
using System.Net.Http.Headers;
using System.Reflection;
using System.Xml;

namespace CreateDatabase // Note: actual namespace depends on the project name.
{
    internal class Program {
        static void Main(string[] args) {
            var cmdFolder = args[0];
            var inputFolder = args[1];

            if (!Directory.Exists(inputFolder)) return;
            if (!Directory.Exists(cmdFolder)) Directory.CreateDirectory(cmdFolder);

            var endInfo = EnvInfo.Instance;

            var tabSpaces = new List<string>();
            var tsInput = Path.Combine(inputFolder, $"TABLESPACES.csv");
            using (var reader = File.OpenText(tsInput)) {
                var csvReader = new CsvReader(reader, false);

                while (csvReader.Next()) {
                    tabSpaces.Add(csvReader.Values[0].Trim());
                }
            }

            var cmdF = Path.Combine(cmdFolder, $"createDatabase.bat");
            var cmdL = Path.Combine(cmdFolder, $"createDatabase.log");
            var sqlE = Path.Combine(cmdFolder, $"createDatabase.sql");
            using (var cmdWriter = File.CreateText(cmdF)) {
                cmdWriter.WriteLine($"call \"{Path.Combine(cmdFolder, "setenv.bat")}\"");
                cmdWriter.WriteLine($"db2 CREATE DATABASE {endInfo.DbName} > \"{cmdL}\"");
                cmdWriter.WriteLine($"db2 connect to {endInfo.DbName} user {endInfo.DbUser} using {endInfo.DbPass} > \"{cmdL}\"");
                cmdWriter.WriteLine($"db2 -tvmf \"{sqlE}\" >> \"{cmdL}\"");
                cmdWriter.WriteLine($"db2 terminate");
            }
            using (var cmdWriter = File.CreateText(sqlE)) {
                cmdWriter.WriteLine($"CREATE SCHEMA {endInfo.DbSchema};");

                foreach (var ts in tabSpaces) {
                    cmdWriter.WriteLine($"CREATE TABLESPACE {ts};");

                }
            }
        }
    }
    class EnvInfo {
        public static EnvInfo Instance = new();
        private EnvInfo() {
            DbName = GetVar("DBNAME", "UDIPPV26");
            DbSchema = GetVar("DBSCHEMA", "IPPV26");
            DbUser = GetVar("DBUSER", "IPPV26");
            DbPass = GetVar("DBPASS", "vnutd3v");
            ExportFolder = GetVar("FdData", "D:\\ING\\Data");
        }

        public string DbName { get; }
        public string DbSchema { get; }
        public string DbUser { get; }
        public string DbPass { get; }

        public string ExportFolder { get; }

        private static string GetVar(string name, string defaultValue)
            => Environment.GetEnvironmentVariable(name) ?? defaultValue;
    }
}